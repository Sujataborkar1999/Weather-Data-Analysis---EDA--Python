```python

```




    
![jpeg](output_0_0.jpg)
    




```python

```


```python
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
```


```python
df = pd.read_csv('Weather data Alfido Tech.csv')
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Time</th>
      <th>Temp_C</th>
      <th>Dew Point Temp_C</th>
      <th>Rel Hum_%</th>
      <th>Wind Speed_km/h</th>
      <th>Visibility_km</th>
      <th>Press_kPa</th>
      <th>Weather</th>
      <th>Unnamed: 9</th>
      <th>Unnamed: 10</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>01-01-2012</td>
      <td>00:00:00</td>
      <td>-1.8</td>
      <td>-3.9</td>
      <td>86</td>
      <td>4</td>
      <td>8.0</td>
      <td>101.24</td>
      <td>Fog</td>
      <td>NaN</td>
      <td></td>
    </tr>
    <tr>
      <th>1</th>
      <td>01-01-2012</td>
      <td>01:00:00</td>
      <td>-1.8</td>
      <td>-3.7</td>
      <td>87</td>
      <td>4</td>
      <td>8.0</td>
      <td>101.24</td>
      <td>Fog</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>01-01-2012</td>
      <td>02:00:00</td>
      <td>-1.8</td>
      <td>-3.4</td>
      <td>89</td>
      <td>7</td>
      <td>4.0</td>
      <td>101.26</td>
      <td>Freezing Drizzle,Fog</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>01-01-2012</td>
      <td>03:00:00</td>
      <td>-1.5</td>
      <td>-3.2</td>
      <td>88</td>
      <td>6</td>
      <td>4.0</td>
      <td>101.27</td>
      <td>Freezing Drizzle,Fog</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>01-01-2012</td>
      <td>04:00:00</td>
      <td>-1.5</td>
      <td>-3.3</td>
      <td>88</td>
      <td>7</td>
      <td>4.8</td>
      <td>101.23</td>
      <td>Fog</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>8779</th>
      <td>12/31/2012</td>
      <td>19:00:00</td>
      <td>0.1</td>
      <td>-2.7</td>
      <td>81</td>
      <td>30</td>
      <td>9.7</td>
      <td>100.13</td>
      <td>Snow</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>8780</th>
      <td>12/31/2012</td>
      <td>20:00:00</td>
      <td>0.2</td>
      <td>-2.4</td>
      <td>83</td>
      <td>24</td>
      <td>9.7</td>
      <td>100.03</td>
      <td>Snow</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>8781</th>
      <td>12/31/2012</td>
      <td>21:00:00</td>
      <td>-0.5</td>
      <td>-1.5</td>
      <td>93</td>
      <td>28</td>
      <td>4.8</td>
      <td>99.95</td>
      <td>Snow</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>8782</th>
      <td>12/31/2012</td>
      <td>22:00:00</td>
      <td>-0.2</td>
      <td>-1.8</td>
      <td>89</td>
      <td>28</td>
      <td>9.7</td>
      <td>99.91</td>
      <td>Snow</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>8783</th>
      <td>12/31/2012</td>
      <td>23:00:00</td>
      <td>0.0</td>
      <td>-2.1</td>
      <td>86</td>
      <td>30</td>
      <td>11.3</td>
      <td>99.89</td>
      <td>Snow</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>8784 rows × 11 columns</p>
</div>




```python
df.shape
```


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    Cell In[8], line 1
    ----> 1 df.shape
    

    NameError: name 'df' is not defined



```python
df.index

```




    RangeIndex(start=0, stop=8784, step=1)




```python
column =df.columns
for columns in column:
    print(columns)
    
```

    Date
    Time
    Temp_C
    Dew Point Temp_C
    Rel Hum_%
    Wind Speed_km/h
    Visibility_km
    Press_kPa
    Weather
    Unnamed: 9
    Unnamed: 10
    


```python
df = df.drop(columns=df.columns[df.columns.str.startswith('Unnamed')])
print(df)
```

                Date      Time  Temp_C  Dew Point Temp_C  Rel Hum_%  \
    0     01-01-2012  00:00:00    -1.8              -3.9         86   
    1     01-01-2012  01:00:00    -1.8              -3.7         87   
    2     01-01-2012  02:00:00    -1.8              -3.4         89   
    3     01-01-2012  03:00:00    -1.5              -3.2         88   
    4     01-01-2012  04:00:00    -1.5              -3.3         88   
    ...          ...       ...     ...               ...        ...   
    8779  12/31/2012  19:00:00     0.1              -2.7         81   
    8780  12/31/2012  20:00:00     0.2              -2.4         83   
    8781  12/31/2012  21:00:00    -0.5              -1.5         93   
    8782  12/31/2012  22:00:00    -0.2              -1.8         89   
    8783  12/31/2012  23:00:00     0.0              -2.1         86   
    
          Wind Speed_km/h  Visibility_km  Press_kPa               Weather  
    0                   4            8.0     101.24                   Fog  
    1                   4            8.0     101.24                   Fog  
    2                   7            4.0     101.26  Freezing Drizzle,Fog  
    3                   6            4.0     101.27  Freezing Drizzle,Fog  
    4                   7            4.8     101.23                   Fog  
    ...               ...            ...        ...                   ...  
    8779               30            9.7     100.13                  Snow  
    8780               24            9.7     100.03                  Snow  
    8781               28            4.8      99.95                  Snow  
    8782               28            9.7      99.91                  Snow  
    8783               30           11.3      99.89                  Snow  
    
    [8784 rows x 9 columns]
    


```python
df.dtypes
```




    Date                 object
    Time                 object
    Temp_C              float64
    Dew Point Temp_C    float64
    Rel Hum_%             int64
    Wind Speed_km/h       int64
    Visibility_km       float64
    Press_kPa           float64
    Weather              object
    dtype: object




```python
weather = df['Weather'].unique()
for weathers in weather:
    print(weathers)
```

    Fog
    Freezing Drizzle,Fog
    Mostly Cloudy
    Cloudy
    Rain
    Rain Showers
    Mainly Clear
    Snow Showers
    Snow
    Clear
    Freezing Rain,Fog
    Freezing Rain
    Freezing Drizzle
    Rain,Snow
    Moderate Snow
    Freezing Drizzle,Snow
    Freezing Rain,Snow Grains
    Snow,Blowing Snow
    Freezing Fog
    Haze
    Rain,Fog
    Drizzle,Fog
    Drizzle
    Freezing Drizzle,Haze
    Freezing Rain,Haze
    Snow,Haze
    Snow,Fog
    Snow,Ice Pellets
    Rain,Haze
    Thunderstorms,Rain
    Thunderstorms,Rain Showers
    Thunderstorms,Heavy Rain Showers
    Thunderstorms,Rain Showers,Fog
    Thunderstorms
    Thunderstorms,Rain,Fog
    Thunderstorms,Moderate Rain Showers,Fog
    Rain Showers,Fog
    Rain Showers,Snow Showers
    Snow Pellets
    Rain,Snow,Fog
    Moderate Rain,Fog
    Freezing Rain,Ice Pellets,Fog
    Drizzle,Ice Pellets,Fog
    Drizzle,Snow
    Rain,Ice Pellets
    Drizzle,Snow,Fog
    Rain,Snow Grains
    Rain,Snow,Ice Pellets
    Snow Showers,Fog
    Moderate Snow,Blowing Snow
    


```python

```


```python
df.nunique()
```




    Date                366
    Time                 24
    Temp_C              533
    Dew Point Temp_C    489
    Rel Hum_%            83
    Wind Speed_km/h      34
    Visibility_km        24
    Press_kPa           518
    Weather              50
    dtype: int64




```python
df.count()
```




    Date                8784
    Time                8784
    Temp_C              8784
    Dew Point Temp_C    8784
    Rel Hum_%           8784
    Wind Speed_km/h     8784
    Visibility_km       8784
    Press_kPa           8784
    Weather             8784
    dtype: int64




```python
df['Weather'].value_counts()
```




    Mainly Clear                               2106
    Mostly Cloudy                              2069
    Cloudy                                     1728
    Clear                                      1326
    Snow                                        390
    Rain                                        306
    Rain Showers                                188
    Fog                                         150
    Rain,Fog                                    116
    Drizzle,Fog                                  80
    Snow Showers                                 60
    Drizzle                                      41
    Snow,Fog                                     37
    Snow,Blowing Snow                            19
    Rain,Snow                                    18
    Thunderstorms,Rain Showers                   16
    Haze                                         16
    Drizzle,Snow,Fog                             15
    Freezing Rain                                14
    Freezing Drizzle,Snow                        11
    Freezing Drizzle                              7
    Snow,Ice Pellets                              6
    Freezing Drizzle,Fog                          6
    Snow,Haze                                     5
    Freezing Fog                                  4
    Snow Showers,Fog                              4
    Moderate Snow                                 4
    Rain,Snow,Ice Pellets                         4
    Freezing Rain,Fog                             4
    Freezing Drizzle,Haze                         3
    Rain,Haze                                     3
    Thunderstorms,Rain                            3
    Thunderstorms,Rain Showers,Fog                3
    Freezing Rain,Haze                            2
    Drizzle,Snow                                  2
    Rain Showers,Snow Showers                     2
    Thunderstorms                                 2
    Moderate Snow,Blowing Snow                    2
    Rain Showers,Fog                              1
    Thunderstorms,Moderate Rain Showers,Fog       1
    Snow Pellets                                  1
    Rain,Snow,Fog                                 1
    Moderate Rain,Fog                             1
    Freezing Rain,Ice Pellets,Fog                 1
    Drizzle,Ice Pellets,Fog                       1
    Thunderstorms,Rain,Fog                        1
    Rain,Ice Pellets                              1
    Rain,Snow Grains                              1
    Thunderstorms,Heavy Rain Showers              1
    Freezing Rain,Snow Grains                     1
    Name: Weather, dtype: int64




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 8784 entries, 0 to 8783
    Data columns (total 9 columns):
     #   Column            Non-Null Count  Dtype  
    ---  ------            --------------  -----  
     0   Date              8784 non-null   object 
     1   Time              8784 non-null   object 
     2   Temp_C            8784 non-null   float64
     3   Dew Point Temp_C  8784 non-null   float64
     4   Rel Hum_%         8784 non-null   int64  
     5   Wind Speed_km/h   8784 non-null   int64  
     6   Visibility_km     8784 non-null   float64
     7   Press_kPa         8784 non-null   float64
     8   Weather           8784 non-null   object 
    dtypes: float64(4), int64(2), object(3)
    memory usage: 617.8+ KB
    


```python
wind_speed = df['Wind Speed_km/h'].nunique()
print('Wind Speed_km/h:-',wind_speed)
```

    Wind Speed_km/h:- 34
    


```python
df['Wind Speed_km/h'].unique()
```




    array([ 4,  7,  6,  9, 15, 13, 20, 22, 19, 24, 30, 35, 39, 32, 33, 26, 44,
           43, 48, 37, 28, 17, 11,  0, 83, 70, 57, 46, 41, 52, 50, 63, 54,  2],
          dtype=int64)




```python
df.head(2)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Time</th>
      <th>Temp_C</th>
      <th>Dew Point Temp_C</th>
      <th>Rel Hum_%</th>
      <th>Wind Speed_km/h</th>
      <th>Visibility_km</th>
      <th>Press_kPa</th>
      <th>Weather</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>01-01-2012</td>
      <td>00:00:00</td>
      <td>-1.8</td>
      <td>-3.9</td>
      <td>86</td>
      <td>4</td>
      <td>8.0</td>
      <td>101.24</td>
      <td>Fog</td>
    </tr>
    <tr>
      <th>1</th>
      <td>01-01-2012</td>
      <td>01:00:00</td>
      <td>-1.8</td>
      <td>-3.7</td>
      <td>87</td>
      <td>4</td>
      <td>8.0</td>
      <td>101.24</td>
      <td>Fog</td>
    </tr>
  </tbody>
</table>
</div>




```python
df['Weather'].value_counts()
```




    Mainly Clear                               2106
    Mostly Cloudy                              2069
    Cloudy                                     1728
    Clear                                      1326
    Snow                                        390
    Rain                                        306
    Rain Showers                                188
    Fog                                         150
    Rain,Fog                                    116
    Drizzle,Fog                                  80
    Snow Showers                                 60
    Drizzle                                      41
    Snow,Fog                                     37
    Snow,Blowing Snow                            19
    Rain,Snow                                    18
    Thunderstorms,Rain Showers                   16
    Haze                                         16
    Drizzle,Snow,Fog                             15
    Freezing Rain                                14
    Freezing Drizzle,Snow                        11
    Freezing Drizzle                              7
    Snow,Ice Pellets                              6
    Freezing Drizzle,Fog                          6
    Snow,Haze                                     5
    Freezing Fog                                  4
    Snow Showers,Fog                              4
    Moderate Snow                                 4
    Rain,Snow,Ice Pellets                         4
    Freezing Rain,Fog                             4
    Freezing Drizzle,Haze                         3
    Rain,Haze                                     3
    Thunderstorms,Rain                            3
    Thunderstorms,Rain Showers,Fog                3
    Freezing Rain,Haze                            2
    Drizzle,Snow                                  2
    Rain Showers,Snow Showers                     2
    Thunderstorms                                 2
    Moderate Snow,Blowing Snow                    2
    Rain Showers,Fog                              1
    Thunderstorms,Moderate Rain Showers,Fog       1
    Snow Pellets                                  1
    Rain,Snow,Fog                                 1
    Moderate Rain,Fog                             1
    Freezing Rain,Ice Pellets,Fog                 1
    Drizzle,Ice Pellets,Fog                       1
    Thunderstorms,Rain,Fog                        1
    Rain,Ice Pellets                              1
    Rain,Snow Grains                              1
    Thunderstorms,Heavy Rain Showers              1
    Freezing Rain,Snow Grains                     1
    Name: Weather, dtype: int64




```python
df[df.Weather == 'Clear']
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Time</th>
      <th>Temp_C</th>
      <th>Dew Point Temp_C</th>
      <th>Rel Hum_%</th>
      <th>Wind Speed_km/h</th>
      <th>Visibility_km</th>
      <th>Press_kPa</th>
      <th>Weather</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>67</th>
      <td>01-03-2012</td>
      <td>19:00:00</td>
      <td>-16.9</td>
      <td>-24.8</td>
      <td>50</td>
      <td>24</td>
      <td>25.0</td>
      <td>101.74</td>
      <td>Clear</td>
    </tr>
    <tr>
      <th>114</th>
      <td>01-05-2012</td>
      <td>18:00:00</td>
      <td>-7.1</td>
      <td>-14.4</td>
      <td>56</td>
      <td>11</td>
      <td>25.0</td>
      <td>100.71</td>
      <td>Clear</td>
    </tr>
    <tr>
      <th>115</th>
      <td>01-05-2012</td>
      <td>19:00:00</td>
      <td>-9.2</td>
      <td>-15.4</td>
      <td>61</td>
      <td>7</td>
      <td>25.0</td>
      <td>100.80</td>
      <td>Clear</td>
    </tr>
    <tr>
      <th>116</th>
      <td>01-05-2012</td>
      <td>20:00:00</td>
      <td>-9.8</td>
      <td>-15.7</td>
      <td>62</td>
      <td>9</td>
      <td>25.0</td>
      <td>100.83</td>
      <td>Clear</td>
    </tr>
    <tr>
      <th>117</th>
      <td>01-05-2012</td>
      <td>21:00:00</td>
      <td>-9.0</td>
      <td>-14.8</td>
      <td>63</td>
      <td>13</td>
      <td>25.0</td>
      <td>100.83</td>
      <td>Clear</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>8646</th>
      <td>12/26/2012</td>
      <td>06:00:00</td>
      <td>-13.4</td>
      <td>-14.8</td>
      <td>89</td>
      <td>4</td>
      <td>25.0</td>
      <td>102.47</td>
      <td>Clear</td>
    </tr>
    <tr>
      <th>8698</th>
      <td>12/28/2012</td>
      <td>10:00:00</td>
      <td>-6.1</td>
      <td>-8.6</td>
      <td>82</td>
      <td>19</td>
      <td>24.1</td>
      <td>101.27</td>
      <td>Clear</td>
    </tr>
    <tr>
      <th>8713</th>
      <td>12/29/2012</td>
      <td>01:00:00</td>
      <td>-11.9</td>
      <td>-13.6</td>
      <td>87</td>
      <td>11</td>
      <td>25.0</td>
      <td>101.31</td>
      <td>Clear</td>
    </tr>
    <tr>
      <th>8714</th>
      <td>12/29/2012</td>
      <td>02:00:00</td>
      <td>-11.8</td>
      <td>-13.1</td>
      <td>90</td>
      <td>13</td>
      <td>25.0</td>
      <td>101.33</td>
      <td>Clear</td>
    </tr>
    <tr>
      <th>8756</th>
      <td>12/30/2012</td>
      <td>20:00:00</td>
      <td>-13.8</td>
      <td>-16.5</td>
      <td>80</td>
      <td>24</td>
      <td>25.0</td>
      <td>101.52</td>
      <td>Clear</td>
    </tr>
  </tbody>
</table>
<p>1326 rows × 9 columns</p>
</div>




```python
df.groupby("Weather").get_group('Clear')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Time</th>
      <th>Temp_C</th>
      <th>Dew Point Temp_C</th>
      <th>Rel Hum_%</th>
      <th>Wind Speed_km/h</th>
      <th>Visibility_km</th>
      <th>Press_kPa</th>
      <th>Weather</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>67</th>
      <td>01-03-2012</td>
      <td>19:00:00</td>
      <td>-16.9</td>
      <td>-24.8</td>
      <td>50</td>
      <td>24</td>
      <td>25.0</td>
      <td>101.74</td>
      <td>Clear</td>
    </tr>
    <tr>
      <th>114</th>
      <td>01-05-2012</td>
      <td>18:00:00</td>
      <td>-7.1</td>
      <td>-14.4</td>
      <td>56</td>
      <td>11</td>
      <td>25.0</td>
      <td>100.71</td>
      <td>Clear</td>
    </tr>
    <tr>
      <th>115</th>
      <td>01-05-2012</td>
      <td>19:00:00</td>
      <td>-9.2</td>
      <td>-15.4</td>
      <td>61</td>
      <td>7</td>
      <td>25.0</td>
      <td>100.80</td>
      <td>Clear</td>
    </tr>
    <tr>
      <th>116</th>
      <td>01-05-2012</td>
      <td>20:00:00</td>
      <td>-9.8</td>
      <td>-15.7</td>
      <td>62</td>
      <td>9</td>
      <td>25.0</td>
      <td>100.83</td>
      <td>Clear</td>
    </tr>
    <tr>
      <th>117</th>
      <td>01-05-2012</td>
      <td>21:00:00</td>
      <td>-9.0</td>
      <td>-14.8</td>
      <td>63</td>
      <td>13</td>
      <td>25.0</td>
      <td>100.83</td>
      <td>Clear</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>8646</th>
      <td>12/26/2012</td>
      <td>06:00:00</td>
      <td>-13.4</td>
      <td>-14.8</td>
      <td>89</td>
      <td>4</td>
      <td>25.0</td>
      <td>102.47</td>
      <td>Clear</td>
    </tr>
    <tr>
      <th>8698</th>
      <td>12/28/2012</td>
      <td>10:00:00</td>
      <td>-6.1</td>
      <td>-8.6</td>
      <td>82</td>
      <td>19</td>
      <td>24.1</td>
      <td>101.27</td>
      <td>Clear</td>
    </tr>
    <tr>
      <th>8713</th>
      <td>12/29/2012</td>
      <td>01:00:00</td>
      <td>-11.9</td>
      <td>-13.6</td>
      <td>87</td>
      <td>11</td>
      <td>25.0</td>
      <td>101.31</td>
      <td>Clear</td>
    </tr>
    <tr>
      <th>8714</th>
      <td>12/29/2012</td>
      <td>02:00:00</td>
      <td>-11.8</td>
      <td>-13.1</td>
      <td>90</td>
      <td>13</td>
      <td>25.0</td>
      <td>101.33</td>
      <td>Clear</td>
    </tr>
    <tr>
      <th>8756</th>
      <td>12/30/2012</td>
      <td>20:00:00</td>
      <td>-13.8</td>
      <td>-16.5</td>
      <td>80</td>
      <td>24</td>
      <td>25.0</td>
      <td>101.52</td>
      <td>Clear</td>
    </tr>
  </tbody>
</table>
<p>1326 rows × 9 columns</p>
</div>




```python
df.groupby("Wind Speed_km/h").get_group(4).count()
```




    Date                474
    Time                474
    Temp_C              474
    Dew Point Temp_C    474
    Rel Hum_%           474
    Wind Speed_km/h     474
    Visibility_km       474
    Press_kPa           474
    Weather             474
    dtype: int64




```python

```


```python
df[df['Wind Speed_km/h'] == 4]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Time</th>
      <th>Temp_C</th>
      <th>Dew Point Temp_C</th>
      <th>Rel Hum_%</th>
      <th>Wind Speed_km/h</th>
      <th>Visibility_km</th>
      <th>Press_kPa</th>
      <th>Weather</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>01-01-2012</td>
      <td>00:00:00</td>
      <td>-1.8</td>
      <td>-3.9</td>
      <td>86</td>
      <td>4</td>
      <td>8.0</td>
      <td>101.24</td>
      <td>Fog</td>
    </tr>
    <tr>
      <th>1</th>
      <td>01-01-2012</td>
      <td>01:00:00</td>
      <td>-1.8</td>
      <td>-3.7</td>
      <td>87</td>
      <td>4</td>
      <td>8.0</td>
      <td>101.24</td>
      <td>Fog</td>
    </tr>
    <tr>
      <th>96</th>
      <td>01-05-2012</td>
      <td>00:00:00</td>
      <td>-8.8</td>
      <td>-11.7</td>
      <td>79</td>
      <td>4</td>
      <td>9.7</td>
      <td>100.32</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>101</th>
      <td>01-05-2012</td>
      <td>05:00:00</td>
      <td>-7.0</td>
      <td>-9.5</td>
      <td>82</td>
      <td>4</td>
      <td>4.0</td>
      <td>100.19</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>146</th>
      <td>01-07-2012</td>
      <td>02:00:00</td>
      <td>-8.1</td>
      <td>-11.1</td>
      <td>79</td>
      <td>4</td>
      <td>19.3</td>
      <td>100.15</td>
      <td>Cloudy</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>8768</th>
      <td>12/31/2012</td>
      <td>08:00:00</td>
      <td>-8.6</td>
      <td>-10.3</td>
      <td>87</td>
      <td>4</td>
      <td>3.2</td>
      <td>101.14</td>
      <td>Snow Showers</td>
    </tr>
    <tr>
      <th>8769</th>
      <td>12/31/2012</td>
      <td>09:00:00</td>
      <td>-8.1</td>
      <td>-9.6</td>
      <td>89</td>
      <td>4</td>
      <td>2.4</td>
      <td>101.09</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>8770</th>
      <td>12/31/2012</td>
      <td>10:00:00</td>
      <td>-7.4</td>
      <td>-8.9</td>
      <td>89</td>
      <td>4</td>
      <td>6.4</td>
      <td>101.05</td>
      <td>Snow,Fog</td>
    </tr>
    <tr>
      <th>8772</th>
      <td>12/31/2012</td>
      <td>12:00:00</td>
      <td>-5.8</td>
      <td>-7.5</td>
      <td>88</td>
      <td>4</td>
      <td>12.9</td>
      <td>100.78</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>8773</th>
      <td>12/31/2012</td>
      <td>13:00:00</td>
      <td>-4.6</td>
      <td>-6.6</td>
      <td>86</td>
      <td>4</td>
      <td>12.9</td>
      <td>100.63</td>
      <td>Snow</td>
    </tr>
  </tbody>
</table>
<p>474 rows × 9 columns</p>
</div>




```python
df.isnull().sum()
```




    Date                0
    Time                0
    Temp_C              0
    Dew Point Temp_C    0
    Rel Hum_%           0
    Wind Speed_km/h     0
    Visibility_km       0
    Press_kPa           0
    Weather             0
    dtype: int64




```python
df.rename(columns = {'Weather': 'Weather condition'}, inplace = True)
```


```python
df.head(3)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Time</th>
      <th>Temp_C</th>
      <th>Dew Point Temp_C</th>
      <th>Rel Hum_%</th>
      <th>Wind Speed_km/h</th>
      <th>Visibility_km</th>
      <th>Press_kPa</th>
      <th>Weather condition</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>01-01-2012</td>
      <td>00:00:00</td>
      <td>-1.8</td>
      <td>-3.9</td>
      <td>86</td>
      <td>4</td>
      <td>8.0</td>
      <td>101.24</td>
      <td>Fog</td>
    </tr>
    <tr>
      <th>1</th>
      <td>01-01-2012</td>
      <td>01:00:00</td>
      <td>-1.8</td>
      <td>-3.7</td>
      <td>87</td>
      <td>4</td>
      <td>8.0</td>
      <td>101.24</td>
      <td>Fog</td>
    </tr>
    <tr>
      <th>2</th>
      <td>01-01-2012</td>
      <td>02:00:00</td>
      <td>-1.8</td>
      <td>-3.4</td>
      <td>89</td>
      <td>7</td>
      <td>4.0</td>
      <td>101.26</td>
      <td>Freezing Drizzle,Fog</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.describe().transpose()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>count</th>
      <th>mean</th>
      <th>std</th>
      <th>min</th>
      <th>25%</th>
      <th>50%</th>
      <th>75%</th>
      <th>max</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Temp_C</th>
      <td>8784.0</td>
      <td>8.798144</td>
      <td>11.687883</td>
      <td>-23.30</td>
      <td>0.10</td>
      <td>9.30</td>
      <td>18.80</td>
      <td>33.00</td>
    </tr>
    <tr>
      <th>Dew Point Temp_C</th>
      <td>8784.0</td>
      <td>2.555294</td>
      <td>10.883072</td>
      <td>-28.50</td>
      <td>-5.90</td>
      <td>3.30</td>
      <td>11.80</td>
      <td>24.40</td>
    </tr>
    <tr>
      <th>Rel Hum_%</th>
      <td>8784.0</td>
      <td>67.431694</td>
      <td>16.918881</td>
      <td>18.00</td>
      <td>56.00</td>
      <td>68.00</td>
      <td>81.00</td>
      <td>100.00</td>
    </tr>
    <tr>
      <th>Wind Speed_km/h</th>
      <td>8784.0</td>
      <td>14.945469</td>
      <td>8.688696</td>
      <td>0.00</td>
      <td>9.00</td>
      <td>13.00</td>
      <td>20.00</td>
      <td>83.00</td>
    </tr>
    <tr>
      <th>Visibility_km</th>
      <td>8784.0</td>
      <td>27.664447</td>
      <td>12.622688</td>
      <td>0.20</td>
      <td>24.10</td>
      <td>25.00</td>
      <td>25.00</td>
      <td>48.30</td>
    </tr>
    <tr>
      <th>Press_kPa</th>
      <td>8784.0</td>
      <td>101.051623</td>
      <td>0.844005</td>
      <td>97.52</td>
      <td>100.56</td>
      <td>101.07</td>
      <td>101.59</td>
      <td>103.65</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.rename(columns = {'Rel Hum_%' : 'Humidity'} , inplace = True)
```


```python
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Temp_C</th>
      <th>Dew Point Temp_C</th>
      <th>Humidity</th>
      <th>Wind Speed_km/h</th>
      <th>Visibility_km</th>
      <th>Press_kPa</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>8784.000000</td>
      <td>8784.000000</td>
      <td>8784.000000</td>
      <td>8784.000000</td>
      <td>8784.000000</td>
      <td>8784.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>8.798144</td>
      <td>2.555294</td>
      <td>67.431694</td>
      <td>14.945469</td>
      <td>27.664447</td>
      <td>101.051623</td>
    </tr>
    <tr>
      <th>std</th>
      <td>11.687883</td>
      <td>10.883072</td>
      <td>16.918881</td>
      <td>8.688696</td>
      <td>12.622688</td>
      <td>0.844005</td>
    </tr>
    <tr>
      <th>min</th>
      <td>-23.300000</td>
      <td>-28.500000</td>
      <td>18.000000</td>
      <td>0.000000</td>
      <td>0.200000</td>
      <td>97.520000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>0.100000</td>
      <td>-5.900000</td>
      <td>56.000000</td>
      <td>9.000000</td>
      <td>24.100000</td>
      <td>100.560000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>9.300000</td>
      <td>3.300000</td>
      <td>68.000000</td>
      <td>13.000000</td>
      <td>25.000000</td>
      <td>101.070000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>18.800000</td>
      <td>11.800000</td>
      <td>81.000000</td>
      <td>20.000000</td>
      <td>25.000000</td>
      <td>101.590000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>33.000000</td>
      <td>24.400000</td>
      <td>100.000000</td>
      <td>83.000000</td>
      <td>48.300000</td>
      <td>103.650000</td>
    </tr>
  </tbody>
</table>
</div>



<div style="background-color: #FF4734; padding: 10px;">
    <h2 style="color: white;">Show all records where weather condition is snow</h2>
</div>



```python
df[df["Weather condition"] == 'Snow']
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Time</th>
      <th>Temp_C</th>
      <th>Dew Point Temp_C</th>
      <th>Rel Hum_%</th>
      <th>Wind Speed_km/h</th>
      <th>Visibility_km</th>
      <th>Press_kPa</th>
      <th>Weather condition</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>55</th>
      <td>01-03-2012</td>
      <td>07:00:00</td>
      <td>-14.0</td>
      <td>-19.5</td>
      <td>63</td>
      <td>19</td>
      <td>25.0</td>
      <td>100.95</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>84</th>
      <td>01-04-2012</td>
      <td>12:00:00</td>
      <td>-13.7</td>
      <td>-21.7</td>
      <td>51</td>
      <td>11</td>
      <td>24.1</td>
      <td>101.25</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>86</th>
      <td>01-04-2012</td>
      <td>14:00:00</td>
      <td>-11.3</td>
      <td>-19.0</td>
      <td>53</td>
      <td>7</td>
      <td>19.3</td>
      <td>100.97</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>87</th>
      <td>01-04-2012</td>
      <td>15:00:00</td>
      <td>-10.2</td>
      <td>-16.3</td>
      <td>61</td>
      <td>11</td>
      <td>9.7</td>
      <td>100.89</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>88</th>
      <td>01-04-2012</td>
      <td>16:00:00</td>
      <td>-9.4</td>
      <td>-15.5</td>
      <td>61</td>
      <td>13</td>
      <td>19.3</td>
      <td>100.79</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>8779</th>
      <td>12/31/2012</td>
      <td>19:00:00</td>
      <td>0.1</td>
      <td>-2.7</td>
      <td>81</td>
      <td>30</td>
      <td>9.7</td>
      <td>100.13</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>8780</th>
      <td>12/31/2012</td>
      <td>20:00:00</td>
      <td>0.2</td>
      <td>-2.4</td>
      <td>83</td>
      <td>24</td>
      <td>9.7</td>
      <td>100.03</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>8781</th>
      <td>12/31/2012</td>
      <td>21:00:00</td>
      <td>-0.5</td>
      <td>-1.5</td>
      <td>93</td>
      <td>28</td>
      <td>4.8</td>
      <td>99.95</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>8782</th>
      <td>12/31/2012</td>
      <td>22:00:00</td>
      <td>-0.2</td>
      <td>-1.8</td>
      <td>89</td>
      <td>28</td>
      <td>9.7</td>
      <td>99.91</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>8783</th>
      <td>12/31/2012</td>
      <td>23:00:00</td>
      <td>0.0</td>
      <td>-2.1</td>
      <td>86</td>
      <td>30</td>
      <td>11.3</td>
      <td>99.89</td>
      <td>Snow</td>
    </tr>
  </tbody>
</table>
<p>390 rows × 9 columns</p>
</div>




```python
df[df['Weather condition'].str.contains('Snow')].head(50)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Time</th>
      <th>Temp_C</th>
      <th>Dew Point Temp_C</th>
      <th>Rel Hum_%</th>
      <th>Wind Speed_km/h</th>
      <th>Visibility_km</th>
      <th>Press_kPa</th>
      <th>Weather condition</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>41</th>
      <td>01-02-2012</td>
      <td>17:00:00</td>
      <td>-2.1</td>
      <td>-9.5</td>
      <td>57</td>
      <td>22</td>
      <td>25.0</td>
      <td>99.66</td>
      <td>Snow Showers</td>
    </tr>
    <tr>
      <th>44</th>
      <td>01-02-2012</td>
      <td>20:00:00</td>
      <td>-5.6</td>
      <td>-13.4</td>
      <td>54</td>
      <td>24</td>
      <td>25.0</td>
      <td>100.07</td>
      <td>Snow Showers</td>
    </tr>
    <tr>
      <th>45</th>
      <td>01-02-2012</td>
      <td>21:00:00</td>
      <td>-5.8</td>
      <td>-12.8</td>
      <td>58</td>
      <td>26</td>
      <td>25.0</td>
      <td>100.15</td>
      <td>Snow Showers</td>
    </tr>
    <tr>
      <th>47</th>
      <td>01-02-2012</td>
      <td>23:00:00</td>
      <td>-7.4</td>
      <td>-14.1</td>
      <td>59</td>
      <td>17</td>
      <td>19.3</td>
      <td>100.27</td>
      <td>Snow Showers</td>
    </tr>
    <tr>
      <th>48</th>
      <td>01-03-2012</td>
      <td>00:00:00</td>
      <td>-9.0</td>
      <td>-16.0</td>
      <td>57</td>
      <td>28</td>
      <td>25.0</td>
      <td>100.35</td>
      <td>Snow Showers</td>
    </tr>
    <tr>
      <th>50</th>
      <td>01-03-2012</td>
      <td>02:00:00</td>
      <td>-10.5</td>
      <td>-15.8</td>
      <td>65</td>
      <td>22</td>
      <td>12.9</td>
      <td>100.53</td>
      <td>Snow Showers</td>
    </tr>
    <tr>
      <th>51</th>
      <td>01-03-2012</td>
      <td>03:00:00</td>
      <td>-11.3</td>
      <td>-18.7</td>
      <td>54</td>
      <td>33</td>
      <td>25.0</td>
      <td>100.61</td>
      <td>Snow Showers</td>
    </tr>
    <tr>
      <th>53</th>
      <td>01-03-2012</td>
      <td>05:00:00</td>
      <td>-12.9</td>
      <td>-19.1</td>
      <td>60</td>
      <td>22</td>
      <td>25.0</td>
      <td>100.76</td>
      <td>Snow Showers</td>
    </tr>
    <tr>
      <th>54</th>
      <td>01-03-2012</td>
      <td>06:00:00</td>
      <td>-13.3</td>
      <td>-19.3</td>
      <td>61</td>
      <td>19</td>
      <td>25.0</td>
      <td>100.85</td>
      <td>Snow Showers</td>
    </tr>
    <tr>
      <th>55</th>
      <td>01-03-2012</td>
      <td>07:00:00</td>
      <td>-14.0</td>
      <td>-19.5</td>
      <td>63</td>
      <td>19</td>
      <td>25.0</td>
      <td>100.95</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>84</th>
      <td>01-04-2012</td>
      <td>12:00:00</td>
      <td>-13.7</td>
      <td>-21.7</td>
      <td>51</td>
      <td>11</td>
      <td>24.1</td>
      <td>101.25</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>86</th>
      <td>01-04-2012</td>
      <td>14:00:00</td>
      <td>-11.3</td>
      <td>-19.0</td>
      <td>53</td>
      <td>7</td>
      <td>19.3</td>
      <td>100.97</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>87</th>
      <td>01-04-2012</td>
      <td>15:00:00</td>
      <td>-10.2</td>
      <td>-16.3</td>
      <td>61</td>
      <td>11</td>
      <td>9.7</td>
      <td>100.89</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>88</th>
      <td>01-04-2012</td>
      <td>16:00:00</td>
      <td>-9.4</td>
      <td>-15.5</td>
      <td>61</td>
      <td>13</td>
      <td>19.3</td>
      <td>100.79</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>89</th>
      <td>01-04-2012</td>
      <td>17:00:00</td>
      <td>-8.9</td>
      <td>-13.2</td>
      <td>71</td>
      <td>9</td>
      <td>4.8</td>
      <td>100.76</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>90</th>
      <td>01-04-2012</td>
      <td>18:00:00</td>
      <td>-8.9</td>
      <td>-12.6</td>
      <td>75</td>
      <td>11</td>
      <td>9.7</td>
      <td>100.69</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>91</th>
      <td>01-04-2012</td>
      <td>19:00:00</td>
      <td>-8.4</td>
      <td>-12.7</td>
      <td>71</td>
      <td>9</td>
      <td>16.1</td>
      <td>100.65</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>92</th>
      <td>01-04-2012</td>
      <td>20:00:00</td>
      <td>-7.8</td>
      <td>-12.1</td>
      <td>71</td>
      <td>9</td>
      <td>16.1</td>
      <td>100.61</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>93</th>
      <td>01-04-2012</td>
      <td>21:00:00</td>
      <td>-7.6</td>
      <td>-11.6</td>
      <td>73</td>
      <td>7</td>
      <td>11.3</td>
      <td>100.54</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>94</th>
      <td>01-04-2012</td>
      <td>22:00:00</td>
      <td>-9.5</td>
      <td>-12.7</td>
      <td>77</td>
      <td>6</td>
      <td>9.7</td>
      <td>100.50</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>95</th>
      <td>01-04-2012</td>
      <td>23:00:00</td>
      <td>-9.6</td>
      <td>-12.6</td>
      <td>79</td>
      <td>6</td>
      <td>9.7</td>
      <td>100.42</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>96</th>
      <td>01-05-2012</td>
      <td>00:00:00</td>
      <td>-8.8</td>
      <td>-11.7</td>
      <td>79</td>
      <td>4</td>
      <td>9.7</td>
      <td>100.32</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>97</th>
      <td>01-05-2012</td>
      <td>01:00:00</td>
      <td>-7.5</td>
      <td>-10.2</td>
      <td>81</td>
      <td>0</td>
      <td>9.7</td>
      <td>100.29</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>98</th>
      <td>01-05-2012</td>
      <td>02:00:00</td>
      <td>-5.4</td>
      <td>-8.3</td>
      <td>80</td>
      <td>9</td>
      <td>8.0</td>
      <td>100.28</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>99</th>
      <td>01-05-2012</td>
      <td>03:00:00</td>
      <td>-5.0</td>
      <td>-7.7</td>
      <td>81</td>
      <td>11</td>
      <td>9.7</td>
      <td>100.24</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>100</th>
      <td>01-05-2012</td>
      <td>04:00:00</td>
      <td>-4.1</td>
      <td>-6.5</td>
      <td>83</td>
      <td>9</td>
      <td>4.8</td>
      <td>100.21</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>101</th>
      <td>01-05-2012</td>
      <td>05:00:00</td>
      <td>-7.0</td>
      <td>-9.5</td>
      <td>82</td>
      <td>4</td>
      <td>4.0</td>
      <td>100.19</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>102</th>
      <td>01-05-2012</td>
      <td>06:00:00</td>
      <td>-8.2</td>
      <td>-10.7</td>
      <td>82</td>
      <td>6</td>
      <td>6.4</td>
      <td>100.26</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>103</th>
      <td>01-05-2012</td>
      <td>07:00:00</td>
      <td>-7.1</td>
      <td>-9.7</td>
      <td>82</td>
      <td>9</td>
      <td>9.7</td>
      <td>100.31</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>104</th>
      <td>01-05-2012</td>
      <td>08:00:00</td>
      <td>-6.1</td>
      <td>-9.1</td>
      <td>79</td>
      <td>11</td>
      <td>9.7</td>
      <td>100.39</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>123</th>
      <td>01-06-2012</td>
      <td>03:00:00</td>
      <td>-10.6</td>
      <td>-16.0</td>
      <td>64</td>
      <td>0</td>
      <td>9.7</td>
      <td>100.76</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>124</th>
      <td>01-06-2012</td>
      <td>04:00:00</td>
      <td>-11.3</td>
      <td>-16.1</td>
      <td>68</td>
      <td>15</td>
      <td>3.2</td>
      <td>100.70</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>125</th>
      <td>01-06-2012</td>
      <td>05:00:00</td>
      <td>-11.8</td>
      <td>-16.0</td>
      <td>71</td>
      <td>19</td>
      <td>2.8</td>
      <td>100.61</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>126</th>
      <td>01-06-2012</td>
      <td>06:00:00</td>
      <td>-12.0</td>
      <td>-16.2</td>
      <td>71</td>
      <td>22</td>
      <td>4.8</td>
      <td>100.58</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>127</th>
      <td>01-06-2012</td>
      <td>07:00:00</td>
      <td>-14.4</td>
      <td>-16.3</td>
      <td>85</td>
      <td>22</td>
      <td>2.4</td>
      <td>100.52</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>128</th>
      <td>01-06-2012</td>
      <td>08:00:00</td>
      <td>-12.3</td>
      <td>-16.2</td>
      <td>73</td>
      <td>24</td>
      <td>11.3</td>
      <td>100.51</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>129</th>
      <td>01-06-2012</td>
      <td>09:00:00</td>
      <td>-12.5</td>
      <td>-16.7</td>
      <td>71</td>
      <td>26</td>
      <td>19.3</td>
      <td>100.53</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>130</th>
      <td>01-06-2012</td>
      <td>10:00:00</td>
      <td>-12.3</td>
      <td>-16.3</td>
      <td>72</td>
      <td>28</td>
      <td>16.1</td>
      <td>100.47</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>131</th>
      <td>01-06-2012</td>
      <td>11:00:00</td>
      <td>-12.0</td>
      <td>-16.0</td>
      <td>72</td>
      <td>17</td>
      <td>24.1</td>
      <td>100.36</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>132</th>
      <td>01-06-2012</td>
      <td>12:00:00</td>
      <td>-11.7</td>
      <td>-15.4</td>
      <td>74</td>
      <td>28</td>
      <td>19.3</td>
      <td>100.23</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>133</th>
      <td>01-06-2012</td>
      <td>13:00:00</td>
      <td>-11.9</td>
      <td>-15.6</td>
      <td>74</td>
      <td>20</td>
      <td>24.1</td>
      <td>100.13</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>134</th>
      <td>01-06-2012</td>
      <td>14:00:00</td>
      <td>-11.2</td>
      <td>-14.8</td>
      <td>75</td>
      <td>19</td>
      <td>19.3</td>
      <td>100.07</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>135</th>
      <td>01-06-2012</td>
      <td>15:00:00</td>
      <td>-11.5</td>
      <td>-14.4</td>
      <td>79</td>
      <td>19</td>
      <td>12.9</td>
      <td>100.06</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>136</th>
      <td>01-06-2012</td>
      <td>16:00:00</td>
      <td>-11.6</td>
      <td>-14.7</td>
      <td>78</td>
      <td>19</td>
      <td>19.3</td>
      <td>100.10</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>137</th>
      <td>01-06-2012</td>
      <td>17:00:00</td>
      <td>-11.2</td>
      <td>-14.3</td>
      <td>78</td>
      <td>17</td>
      <td>25.0</td>
      <td>100.15</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>158</th>
      <td>01-07-2012</td>
      <td>14:00:00</td>
      <td>-4.4</td>
      <td>-6.9</td>
      <td>83</td>
      <td>6</td>
      <td>8.0</td>
      <td>100.09</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>159</th>
      <td>01-07-2012</td>
      <td>15:00:00</td>
      <td>-3.7</td>
      <td>-6.1</td>
      <td>83</td>
      <td>11</td>
      <td>8.0</td>
      <td>100.09</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>160</th>
      <td>01-07-2012</td>
      <td>16:00:00</td>
      <td>-3.6</td>
      <td>-5.9</td>
      <td>84</td>
      <td>0</td>
      <td>8.0</td>
      <td>100.15</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>161</th>
      <td>01-07-2012</td>
      <td>17:00:00</td>
      <td>-3.1</td>
      <td>-5.4</td>
      <td>84</td>
      <td>13</td>
      <td>8.0</td>
      <td>100.27</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>162</th>
      <td>01-07-2012</td>
      <td>18:00:00</td>
      <td>-3.2</td>
      <td>-5.3</td>
      <td>85</td>
      <td>6</td>
      <td>9.7</td>
      <td>100.33</td>
      <td>Snow</td>
    </tr>
  </tbody>
</table>
</div>



<div style="background-color: #FF4734; padding: 10px;">
    <h2 style="color: white;">Show all records where wind speed upto 24 km/h and visibility 25 Km</h2>
</div>



```python
df[df['Weather condition'].str.contains('Snow')].head(50)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Time</th>
      <th>Temp_C</th>
      <th>Dew Point Temp_C</th>
      <th>Rel Hum_%</th>
      <th>Wind Speed_km/h</th>
      <th>Visibility_km</th>
      <th>Press_kPa</th>
      <th>Weather condition</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>41</th>
      <td>01-02-2012</td>
      <td>17:00:00</td>
      <td>-2.1</td>
      <td>-9.5</td>
      <td>57</td>
      <td>22</td>
      <td>25.0</td>
      <td>99.66</td>
      <td>Snow Showers</td>
    </tr>
    <tr>
      <th>44</th>
      <td>01-02-2012</td>
      <td>20:00:00</td>
      <td>-5.6</td>
      <td>-13.4</td>
      <td>54</td>
      <td>24</td>
      <td>25.0</td>
      <td>100.07</td>
      <td>Snow Showers</td>
    </tr>
    <tr>
      <th>45</th>
      <td>01-02-2012</td>
      <td>21:00:00</td>
      <td>-5.8</td>
      <td>-12.8</td>
      <td>58</td>
      <td>26</td>
      <td>25.0</td>
      <td>100.15</td>
      <td>Snow Showers</td>
    </tr>
    <tr>
      <th>47</th>
      <td>01-02-2012</td>
      <td>23:00:00</td>
      <td>-7.4</td>
      <td>-14.1</td>
      <td>59</td>
      <td>17</td>
      <td>19.3</td>
      <td>100.27</td>
      <td>Snow Showers</td>
    </tr>
    <tr>
      <th>48</th>
      <td>01-03-2012</td>
      <td>00:00:00</td>
      <td>-9.0</td>
      <td>-16.0</td>
      <td>57</td>
      <td>28</td>
      <td>25.0</td>
      <td>100.35</td>
      <td>Snow Showers</td>
    </tr>
    <tr>
      <th>50</th>
      <td>01-03-2012</td>
      <td>02:00:00</td>
      <td>-10.5</td>
      <td>-15.8</td>
      <td>65</td>
      <td>22</td>
      <td>12.9</td>
      <td>100.53</td>
      <td>Snow Showers</td>
    </tr>
    <tr>
      <th>51</th>
      <td>01-03-2012</td>
      <td>03:00:00</td>
      <td>-11.3</td>
      <td>-18.7</td>
      <td>54</td>
      <td>33</td>
      <td>25.0</td>
      <td>100.61</td>
      <td>Snow Showers</td>
    </tr>
    <tr>
      <th>53</th>
      <td>01-03-2012</td>
      <td>05:00:00</td>
      <td>-12.9</td>
      <td>-19.1</td>
      <td>60</td>
      <td>22</td>
      <td>25.0</td>
      <td>100.76</td>
      <td>Snow Showers</td>
    </tr>
    <tr>
      <th>54</th>
      <td>01-03-2012</td>
      <td>06:00:00</td>
      <td>-13.3</td>
      <td>-19.3</td>
      <td>61</td>
      <td>19</td>
      <td>25.0</td>
      <td>100.85</td>
      <td>Snow Showers</td>
    </tr>
    <tr>
      <th>55</th>
      <td>01-03-2012</td>
      <td>07:00:00</td>
      <td>-14.0</td>
      <td>-19.5</td>
      <td>63</td>
      <td>19</td>
      <td>25.0</td>
      <td>100.95</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>84</th>
      <td>01-04-2012</td>
      <td>12:00:00</td>
      <td>-13.7</td>
      <td>-21.7</td>
      <td>51</td>
      <td>11</td>
      <td>24.1</td>
      <td>101.25</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>86</th>
      <td>01-04-2012</td>
      <td>14:00:00</td>
      <td>-11.3</td>
      <td>-19.0</td>
      <td>53</td>
      <td>7</td>
      <td>19.3</td>
      <td>100.97</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>87</th>
      <td>01-04-2012</td>
      <td>15:00:00</td>
      <td>-10.2</td>
      <td>-16.3</td>
      <td>61</td>
      <td>11</td>
      <td>9.7</td>
      <td>100.89</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>88</th>
      <td>01-04-2012</td>
      <td>16:00:00</td>
      <td>-9.4</td>
      <td>-15.5</td>
      <td>61</td>
      <td>13</td>
      <td>19.3</td>
      <td>100.79</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>89</th>
      <td>01-04-2012</td>
      <td>17:00:00</td>
      <td>-8.9</td>
      <td>-13.2</td>
      <td>71</td>
      <td>9</td>
      <td>4.8</td>
      <td>100.76</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>90</th>
      <td>01-04-2012</td>
      <td>18:00:00</td>
      <td>-8.9</td>
      <td>-12.6</td>
      <td>75</td>
      <td>11</td>
      <td>9.7</td>
      <td>100.69</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>91</th>
      <td>01-04-2012</td>
      <td>19:00:00</td>
      <td>-8.4</td>
      <td>-12.7</td>
      <td>71</td>
      <td>9</td>
      <td>16.1</td>
      <td>100.65</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>92</th>
      <td>01-04-2012</td>
      <td>20:00:00</td>
      <td>-7.8</td>
      <td>-12.1</td>
      <td>71</td>
      <td>9</td>
      <td>16.1</td>
      <td>100.61</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>93</th>
      <td>01-04-2012</td>
      <td>21:00:00</td>
      <td>-7.6</td>
      <td>-11.6</td>
      <td>73</td>
      <td>7</td>
      <td>11.3</td>
      <td>100.54</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>94</th>
      <td>01-04-2012</td>
      <td>22:00:00</td>
      <td>-9.5</td>
      <td>-12.7</td>
      <td>77</td>
      <td>6</td>
      <td>9.7</td>
      <td>100.50</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>95</th>
      <td>01-04-2012</td>
      <td>23:00:00</td>
      <td>-9.6</td>
      <td>-12.6</td>
      <td>79</td>
      <td>6</td>
      <td>9.7</td>
      <td>100.42</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>96</th>
      <td>01-05-2012</td>
      <td>00:00:00</td>
      <td>-8.8</td>
      <td>-11.7</td>
      <td>79</td>
      <td>4</td>
      <td>9.7</td>
      <td>100.32</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>97</th>
      <td>01-05-2012</td>
      <td>01:00:00</td>
      <td>-7.5</td>
      <td>-10.2</td>
      <td>81</td>
      <td>0</td>
      <td>9.7</td>
      <td>100.29</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>98</th>
      <td>01-05-2012</td>
      <td>02:00:00</td>
      <td>-5.4</td>
      <td>-8.3</td>
      <td>80</td>
      <td>9</td>
      <td>8.0</td>
      <td>100.28</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>99</th>
      <td>01-05-2012</td>
      <td>03:00:00</td>
      <td>-5.0</td>
      <td>-7.7</td>
      <td>81</td>
      <td>11</td>
      <td>9.7</td>
      <td>100.24</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>100</th>
      <td>01-05-2012</td>
      <td>04:00:00</td>
      <td>-4.1</td>
      <td>-6.5</td>
      <td>83</td>
      <td>9</td>
      <td>4.8</td>
      <td>100.21</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>101</th>
      <td>01-05-2012</td>
      <td>05:00:00</td>
      <td>-7.0</td>
      <td>-9.5</td>
      <td>82</td>
      <td>4</td>
      <td>4.0</td>
      <td>100.19</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>102</th>
      <td>01-05-2012</td>
      <td>06:00:00</td>
      <td>-8.2</td>
      <td>-10.7</td>
      <td>82</td>
      <td>6</td>
      <td>6.4</td>
      <td>100.26</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>103</th>
      <td>01-05-2012</td>
      <td>07:00:00</td>
      <td>-7.1</td>
      <td>-9.7</td>
      <td>82</td>
      <td>9</td>
      <td>9.7</td>
      <td>100.31</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>104</th>
      <td>01-05-2012</td>
      <td>08:00:00</td>
      <td>-6.1</td>
      <td>-9.1</td>
      <td>79</td>
      <td>11</td>
      <td>9.7</td>
      <td>100.39</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>123</th>
      <td>01-06-2012</td>
      <td>03:00:00</td>
      <td>-10.6</td>
      <td>-16.0</td>
      <td>64</td>
      <td>0</td>
      <td>9.7</td>
      <td>100.76</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>124</th>
      <td>01-06-2012</td>
      <td>04:00:00</td>
      <td>-11.3</td>
      <td>-16.1</td>
      <td>68</td>
      <td>15</td>
      <td>3.2</td>
      <td>100.70</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>125</th>
      <td>01-06-2012</td>
      <td>05:00:00</td>
      <td>-11.8</td>
      <td>-16.0</td>
      <td>71</td>
      <td>19</td>
      <td>2.8</td>
      <td>100.61</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>126</th>
      <td>01-06-2012</td>
      <td>06:00:00</td>
      <td>-12.0</td>
      <td>-16.2</td>
      <td>71</td>
      <td>22</td>
      <td>4.8</td>
      <td>100.58</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>127</th>
      <td>01-06-2012</td>
      <td>07:00:00</td>
      <td>-14.4</td>
      <td>-16.3</td>
      <td>85</td>
      <td>22</td>
      <td>2.4</td>
      <td>100.52</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>128</th>
      <td>01-06-2012</td>
      <td>08:00:00</td>
      <td>-12.3</td>
      <td>-16.2</td>
      <td>73</td>
      <td>24</td>
      <td>11.3</td>
      <td>100.51</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>129</th>
      <td>01-06-2012</td>
      <td>09:00:00</td>
      <td>-12.5</td>
      <td>-16.7</td>
      <td>71</td>
      <td>26</td>
      <td>19.3</td>
      <td>100.53</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>130</th>
      <td>01-06-2012</td>
      <td>10:00:00</td>
      <td>-12.3</td>
      <td>-16.3</td>
      <td>72</td>
      <td>28</td>
      <td>16.1</td>
      <td>100.47</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>131</th>
      <td>01-06-2012</td>
      <td>11:00:00</td>
      <td>-12.0</td>
      <td>-16.0</td>
      <td>72</td>
      <td>17</td>
      <td>24.1</td>
      <td>100.36</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>132</th>
      <td>01-06-2012</td>
      <td>12:00:00</td>
      <td>-11.7</td>
      <td>-15.4</td>
      <td>74</td>
      <td>28</td>
      <td>19.3</td>
      <td>100.23</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>133</th>
      <td>01-06-2012</td>
      <td>13:00:00</td>
      <td>-11.9</td>
      <td>-15.6</td>
      <td>74</td>
      <td>20</td>
      <td>24.1</td>
      <td>100.13</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>134</th>
      <td>01-06-2012</td>
      <td>14:00:00</td>
      <td>-11.2</td>
      <td>-14.8</td>
      <td>75</td>
      <td>19</td>
      <td>19.3</td>
      <td>100.07</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>135</th>
      <td>01-06-2012</td>
      <td>15:00:00</td>
      <td>-11.5</td>
      <td>-14.4</td>
      <td>79</td>
      <td>19</td>
      <td>12.9</td>
      <td>100.06</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>136</th>
      <td>01-06-2012</td>
      <td>16:00:00</td>
      <td>-11.6</td>
      <td>-14.7</td>
      <td>78</td>
      <td>19</td>
      <td>19.3</td>
      <td>100.10</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>137</th>
      <td>01-06-2012</td>
      <td>17:00:00</td>
      <td>-11.2</td>
      <td>-14.3</td>
      <td>78</td>
      <td>17</td>
      <td>25.0</td>
      <td>100.15</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>158</th>
      <td>01-07-2012</td>
      <td>14:00:00</td>
      <td>-4.4</td>
      <td>-6.9</td>
      <td>83</td>
      <td>6</td>
      <td>8.0</td>
      <td>100.09</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>159</th>
      <td>01-07-2012</td>
      <td>15:00:00</td>
      <td>-3.7</td>
      <td>-6.1</td>
      <td>83</td>
      <td>11</td>
      <td>8.0</td>
      <td>100.09</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>160</th>
      <td>01-07-2012</td>
      <td>16:00:00</td>
      <td>-3.6</td>
      <td>-5.9</td>
      <td>84</td>
      <td>0</td>
      <td>8.0</td>
      <td>100.15</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>161</th>
      <td>01-07-2012</td>
      <td>17:00:00</td>
      <td>-3.1</td>
      <td>-5.4</td>
      <td>84</td>
      <td>13</td>
      <td>8.0</td>
      <td>100.27</td>
      <td>Snow</td>
    </tr>
    <tr>
      <th>162</th>
      <td>01-07-2012</td>
      <td>18:00:00</td>
      <td>-3.2</td>
      <td>-5.3</td>
      <td>85</td>
      <td>6</td>
      <td>9.7</td>
      <td>100.33</td>
      <td>Snow</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.groupby('Weather condition').mean()
```

    C:\Users\bhagi\AppData\Local\Temp\ipykernel_12192\2449544051.py:1: FutureWarning: The default value of numeric_only in DataFrameGroupBy.mean is deprecated. In a future version, numeric_only will default to False. Either specify numeric_only or select only columns which should be valid for the function.
      df.groupby('Weather condition').mean()
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Temp_C</th>
      <th>Dew Point Temp_C</th>
      <th>Rel Hum_%</th>
      <th>Wind Speed_km/h</th>
      <th>Visibility_km</th>
      <th>Press_kPa</th>
    </tr>
    <tr>
      <th>Weather condition</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Clear</th>
      <td>6.825716</td>
      <td>0.089367</td>
      <td>64.497738</td>
      <td>10.557315</td>
      <td>30.153243</td>
      <td>101.587443</td>
    </tr>
    <tr>
      <th>Cloudy</th>
      <td>7.970544</td>
      <td>2.375810</td>
      <td>69.592593</td>
      <td>16.127315</td>
      <td>26.625752</td>
      <td>100.911441</td>
    </tr>
    <tr>
      <th>Drizzle</th>
      <td>7.353659</td>
      <td>5.504878</td>
      <td>88.243902</td>
      <td>16.097561</td>
      <td>17.931707</td>
      <td>100.435366</td>
    </tr>
    <tr>
      <th>Drizzle,Fog</th>
      <td>8.067500</td>
      <td>7.033750</td>
      <td>93.275000</td>
      <td>11.862500</td>
      <td>5.257500</td>
      <td>100.786625</td>
    </tr>
    <tr>
      <th>Drizzle,Ice Pellets,Fog</th>
      <td>0.400000</td>
      <td>-0.700000</td>
      <td>92.000000</td>
      <td>20.000000</td>
      <td>4.000000</td>
      <td>100.790000</td>
    </tr>
    <tr>
      <th>Drizzle,Snow</th>
      <td>1.050000</td>
      <td>0.150000</td>
      <td>93.500000</td>
      <td>14.000000</td>
      <td>10.500000</td>
      <td>100.890000</td>
    </tr>
    <tr>
      <th>Drizzle,Snow,Fog</th>
      <td>0.693333</td>
      <td>0.120000</td>
      <td>95.866667</td>
      <td>15.533333</td>
      <td>5.513333</td>
      <td>99.281333</td>
    </tr>
    <tr>
      <th>Fog</th>
      <td>4.303333</td>
      <td>3.159333</td>
      <td>92.286667</td>
      <td>7.946667</td>
      <td>6.248000</td>
      <td>101.184067</td>
    </tr>
    <tr>
      <th>Freezing Drizzle</th>
      <td>-5.657143</td>
      <td>-8.000000</td>
      <td>83.571429</td>
      <td>16.571429</td>
      <td>9.200000</td>
      <td>100.202857</td>
    </tr>
    <tr>
      <th>Freezing Drizzle,Fog</th>
      <td>-2.533333</td>
      <td>-4.183333</td>
      <td>88.500000</td>
      <td>17.000000</td>
      <td>5.266667</td>
      <td>100.441667</td>
    </tr>
    <tr>
      <th>Freezing Drizzle,Haze</th>
      <td>-5.433333</td>
      <td>-8.000000</td>
      <td>82.000000</td>
      <td>10.333333</td>
      <td>2.666667</td>
      <td>100.316667</td>
    </tr>
    <tr>
      <th>Freezing Drizzle,Snow</th>
      <td>-5.109091</td>
      <td>-7.072727</td>
      <td>86.090909</td>
      <td>16.272727</td>
      <td>5.872727</td>
      <td>100.520909</td>
    </tr>
    <tr>
      <th>Freezing Fog</th>
      <td>-7.575000</td>
      <td>-9.250000</td>
      <td>87.750000</td>
      <td>4.750000</td>
      <td>0.650000</td>
      <td>102.320000</td>
    </tr>
    <tr>
      <th>Freezing Rain</th>
      <td>-3.885714</td>
      <td>-6.078571</td>
      <td>84.642857</td>
      <td>19.214286</td>
      <td>8.242857</td>
      <td>99.647143</td>
    </tr>
    <tr>
      <th>Freezing Rain,Fog</th>
      <td>-2.225000</td>
      <td>-3.750000</td>
      <td>89.500000</td>
      <td>15.500000</td>
      <td>7.550000</td>
      <td>99.945000</td>
    </tr>
    <tr>
      <th>Freezing Rain,Haze</th>
      <td>-4.900000</td>
      <td>-7.450000</td>
      <td>82.500000</td>
      <td>7.500000</td>
      <td>2.400000</td>
      <td>100.375000</td>
    </tr>
    <tr>
      <th>Freezing Rain,Ice Pellets,Fog</th>
      <td>-2.600000</td>
      <td>-3.700000</td>
      <td>92.000000</td>
      <td>28.000000</td>
      <td>8.000000</td>
      <td>100.950000</td>
    </tr>
    <tr>
      <th>Freezing Rain,Snow Grains</th>
      <td>-5.000000</td>
      <td>-7.300000</td>
      <td>84.000000</td>
      <td>32.000000</td>
      <td>4.800000</td>
      <td>98.560000</td>
    </tr>
    <tr>
      <th>Haze</th>
      <td>-0.200000</td>
      <td>-2.975000</td>
      <td>81.625000</td>
      <td>10.437500</td>
      <td>7.831250</td>
      <td>101.482500</td>
    </tr>
    <tr>
      <th>Mainly Clear</th>
      <td>12.558927</td>
      <td>4.581671</td>
      <td>60.667142</td>
      <td>14.144824</td>
      <td>34.264862</td>
      <td>101.248832</td>
    </tr>
    <tr>
      <th>Moderate Rain,Fog</th>
      <td>1.700000</td>
      <td>0.800000</td>
      <td>94.000000</td>
      <td>17.000000</td>
      <td>6.400000</td>
      <td>99.980000</td>
    </tr>
    <tr>
      <th>Moderate Snow</th>
      <td>-5.525000</td>
      <td>-7.250000</td>
      <td>87.750000</td>
      <td>33.750000</td>
      <td>0.750000</td>
      <td>100.275000</td>
    </tr>
    <tr>
      <th>Moderate Snow,Blowing Snow</th>
      <td>-5.450000</td>
      <td>-6.500000</td>
      <td>92.500000</td>
      <td>40.000000</td>
      <td>0.600000</td>
      <td>100.570000</td>
    </tr>
    <tr>
      <th>Mostly Cloudy</th>
      <td>10.574287</td>
      <td>3.131174</td>
      <td>62.102465</td>
      <td>15.813920</td>
      <td>31.253842</td>
      <td>101.025288</td>
    </tr>
    <tr>
      <th>Rain</th>
      <td>9.786275</td>
      <td>7.042810</td>
      <td>83.624183</td>
      <td>19.254902</td>
      <td>18.856536</td>
      <td>100.233333</td>
    </tr>
    <tr>
      <th>Rain Showers</th>
      <td>13.722340</td>
      <td>9.187766</td>
      <td>75.159574</td>
      <td>17.132979</td>
      <td>22.816489</td>
      <td>100.404043</td>
    </tr>
    <tr>
      <th>Rain Showers,Fog</th>
      <td>12.800000</td>
      <td>12.100000</td>
      <td>96.000000</td>
      <td>13.000000</td>
      <td>6.400000</td>
      <td>99.830000</td>
    </tr>
    <tr>
      <th>Rain Showers,Snow Showers</th>
      <td>2.150000</td>
      <td>-1.500000</td>
      <td>76.500000</td>
      <td>22.500000</td>
      <td>21.700000</td>
      <td>101.100000</td>
    </tr>
    <tr>
      <th>Rain,Fog</th>
      <td>8.273276</td>
      <td>7.219828</td>
      <td>93.189655</td>
      <td>14.793103</td>
      <td>6.873276</td>
      <td>100.500862</td>
    </tr>
    <tr>
      <th>Rain,Haze</th>
      <td>4.633333</td>
      <td>2.066667</td>
      <td>83.333333</td>
      <td>11.666667</td>
      <td>6.700000</td>
      <td>100.540000</td>
    </tr>
    <tr>
      <th>Rain,Ice Pellets</th>
      <td>0.600000</td>
      <td>-0.600000</td>
      <td>92.000000</td>
      <td>24.000000</td>
      <td>9.700000</td>
      <td>100.120000</td>
    </tr>
    <tr>
      <th>Rain,Snow</th>
      <td>1.055556</td>
      <td>-0.566667</td>
      <td>89.000000</td>
      <td>28.388889</td>
      <td>11.672222</td>
      <td>99.951111</td>
    </tr>
    <tr>
      <th>Rain,Snow Grains</th>
      <td>1.900000</td>
      <td>-2.100000</td>
      <td>75.000000</td>
      <td>26.000000</td>
      <td>25.000000</td>
      <td>100.600000</td>
    </tr>
    <tr>
      <th>Rain,Snow,Fog</th>
      <td>0.800000</td>
      <td>0.300000</td>
      <td>96.000000</td>
      <td>9.000000</td>
      <td>6.400000</td>
      <td>100.730000</td>
    </tr>
    <tr>
      <th>Rain,Snow,Ice Pellets</th>
      <td>1.100000</td>
      <td>-0.175000</td>
      <td>91.500000</td>
      <td>23.250000</td>
      <td>6.000000</td>
      <td>100.105000</td>
    </tr>
    <tr>
      <th>Snow</th>
      <td>-4.524103</td>
      <td>-7.623333</td>
      <td>79.307692</td>
      <td>20.038462</td>
      <td>11.171795</td>
      <td>100.536103</td>
    </tr>
    <tr>
      <th>Snow Pellets</th>
      <td>0.700000</td>
      <td>-6.400000</td>
      <td>59.000000</td>
      <td>35.000000</td>
      <td>2.400000</td>
      <td>99.700000</td>
    </tr>
    <tr>
      <th>Snow Showers</th>
      <td>-3.506667</td>
      <td>-7.866667</td>
      <td>72.350000</td>
      <td>19.233333</td>
      <td>20.158333</td>
      <td>100.963500</td>
    </tr>
    <tr>
      <th>Snow Showers,Fog</th>
      <td>-10.675000</td>
      <td>-11.900000</td>
      <td>90.750000</td>
      <td>13.750000</td>
      <td>7.025000</td>
      <td>101.292500</td>
    </tr>
    <tr>
      <th>Snow,Blowing Snow</th>
      <td>-5.410526</td>
      <td>-7.621053</td>
      <td>84.473684</td>
      <td>34.842105</td>
      <td>4.105263</td>
      <td>99.704737</td>
    </tr>
    <tr>
      <th>Snow,Fog</th>
      <td>-5.075676</td>
      <td>-6.364865</td>
      <td>90.675676</td>
      <td>17.324324</td>
      <td>4.537838</td>
      <td>100.688649</td>
    </tr>
    <tr>
      <th>Snow,Haze</th>
      <td>-4.020000</td>
      <td>-6.860000</td>
      <td>80.600000</td>
      <td>5.000000</td>
      <td>4.640000</td>
      <td>100.782000</td>
    </tr>
    <tr>
      <th>Snow,Ice Pellets</th>
      <td>-1.883333</td>
      <td>-3.666667</td>
      <td>87.666667</td>
      <td>23.833333</td>
      <td>7.416667</td>
      <td>100.548333</td>
    </tr>
    <tr>
      <th>Thunderstorms</th>
      <td>24.150000</td>
      <td>19.750000</td>
      <td>77.000000</td>
      <td>7.500000</td>
      <td>24.550000</td>
      <td>100.230000</td>
    </tr>
    <tr>
      <th>Thunderstorms,Heavy Rain Showers</th>
      <td>10.900000</td>
      <td>9.000000</td>
      <td>88.000000</td>
      <td>9.000000</td>
      <td>2.400000</td>
      <td>100.260000</td>
    </tr>
    <tr>
      <th>Thunderstorms,Moderate Rain Showers,Fog</th>
      <td>19.600000</td>
      <td>18.500000</td>
      <td>93.000000</td>
      <td>15.000000</td>
      <td>3.200000</td>
      <td>100.010000</td>
    </tr>
    <tr>
      <th>Thunderstorms,Rain</th>
      <td>20.433333</td>
      <td>18.533333</td>
      <td>89.000000</td>
      <td>15.666667</td>
      <td>19.833333</td>
      <td>100.420000</td>
    </tr>
    <tr>
      <th>Thunderstorms,Rain Showers</th>
      <td>20.037500</td>
      <td>17.618750</td>
      <td>86.375000</td>
      <td>18.312500</td>
      <td>15.893750</td>
      <td>100.233750</td>
    </tr>
    <tr>
      <th>Thunderstorms,Rain Showers,Fog</th>
      <td>21.600000</td>
      <td>18.700000</td>
      <td>84.000000</td>
      <td>19.666667</td>
      <td>9.700000</td>
      <td>100.063333</td>
    </tr>
    <tr>
      <th>Thunderstorms,Rain,Fog</th>
      <td>20.600000</td>
      <td>18.600000</td>
      <td>88.000000</td>
      <td>19.000000</td>
      <td>4.800000</td>
      <td>100.080000</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.groupby('Weather condition').min()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Time</th>
      <th>Temp_C</th>
      <th>Dew Point Temp_C</th>
      <th>Rel Hum_%</th>
      <th>Wind Speed_km/h</th>
      <th>Visibility_km</th>
      <th>Press_kPa</th>
    </tr>
    <tr>
      <th>Weather condition</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Clear</th>
      <td>01-03-2012</td>
      <td>00:00:00</td>
      <td>-23.3</td>
      <td>-28.5</td>
      <td>20</td>
      <td>0</td>
      <td>11.3</td>
      <td>99.52</td>
    </tr>
    <tr>
      <th>Cloudy</th>
      <td>01-01-2012</td>
      <td>00:00:00</td>
      <td>-21.4</td>
      <td>-26.8</td>
      <td>18</td>
      <td>0</td>
      <td>11.3</td>
      <td>98.39</td>
    </tr>
    <tr>
      <th>Drizzle</th>
      <td>05-01-2012</td>
      <td>01:00:00</td>
      <td>1.1</td>
      <td>-0.2</td>
      <td>74</td>
      <td>0</td>
      <td>6.4</td>
      <td>97.84</td>
    </tr>
    <tr>
      <th>Drizzle,Fog</th>
      <td>05-01-2012</td>
      <td>00:00:00</td>
      <td>0.0</td>
      <td>-1.6</td>
      <td>85</td>
      <td>0</td>
      <td>1.0</td>
      <td>98.65</td>
    </tr>
    <tr>
      <th>Drizzle,Ice Pellets,Fog</th>
      <td>12/17/2012</td>
      <td>09:00:00</td>
      <td>0.4</td>
      <td>-0.7</td>
      <td>92</td>
      <td>20</td>
      <td>4.0</td>
      <td>100.79</td>
    </tr>
    <tr>
      <th>Drizzle,Snow</th>
      <td>12/17/2012</td>
      <td>15:00:00</td>
      <td>0.9</td>
      <td>0.1</td>
      <td>92</td>
      <td>9</td>
      <td>9.7</td>
      <td>100.63</td>
    </tr>
    <tr>
      <th>Drizzle,Snow,Fog</th>
      <td>12/18/2012</td>
      <td>00:00:00</td>
      <td>0.3</td>
      <td>-0.1</td>
      <td>92</td>
      <td>7</td>
      <td>2.4</td>
      <td>97.79</td>
    </tr>
    <tr>
      <th>Fog</th>
      <td>01-01-2012</td>
      <td>00:00:00</td>
      <td>-16.0</td>
      <td>-17.2</td>
      <td>80</td>
      <td>0</td>
      <td>0.2</td>
      <td>98.31</td>
    </tr>
    <tr>
      <th>Freezing Drizzle</th>
      <td>01-07-2012</td>
      <td>00:00:00</td>
      <td>-9.0</td>
      <td>-12.2</td>
      <td>78</td>
      <td>6</td>
      <td>4.8</td>
      <td>98.44</td>
    </tr>
    <tr>
      <th>Freezing Drizzle,Fog</th>
      <td>01-01-2012</td>
      <td>02:00:00</td>
      <td>-6.4</td>
      <td>-9.0</td>
      <td>82</td>
      <td>6</td>
      <td>3.6</td>
      <td>98.74</td>
    </tr>
    <tr>
      <th>Freezing Drizzle,Haze</th>
      <td>02-01-2012</td>
      <td>11:00:00</td>
      <td>-5.8</td>
      <td>-8.3</td>
      <td>81</td>
      <td>9</td>
      <td>2.0</td>
      <td>100.28</td>
    </tr>
    <tr>
      <th>Freezing Drizzle,Snow</th>
      <td>03-02-2012</td>
      <td>00:00:00</td>
      <td>-8.3</td>
      <td>-10.4</td>
      <td>79</td>
      <td>6</td>
      <td>2.4</td>
      <td>99.19</td>
    </tr>
    <tr>
      <th>Freezing Fog</th>
      <td>02-05-2012</td>
      <td>05:00:00</td>
      <td>-19.0</td>
      <td>-22.9</td>
      <td>71</td>
      <td>0</td>
      <td>0.2</td>
      <td>101.97</td>
    </tr>
    <tr>
      <th>Freezing Rain</th>
      <td>01-07-2012</td>
      <td>02:00:00</td>
      <td>-6.5</td>
      <td>-9.0</td>
      <td>81</td>
      <td>7</td>
      <td>2.8</td>
      <td>98.22</td>
    </tr>
    <tr>
      <th>Freezing Rain,Fog</th>
      <td>01-07-2012</td>
      <td>01:00:00</td>
      <td>-6.1</td>
      <td>-8.7</td>
      <td>82</td>
      <td>7</td>
      <td>2.8</td>
      <td>98.32</td>
    </tr>
    <tr>
      <th>Freezing Rain,Haze</th>
      <td>02-01-2012</td>
      <td>14:00:00</td>
      <td>-4.9</td>
      <td>-7.5</td>
      <td>82</td>
      <td>6</td>
      <td>2.0</td>
      <td>100.34</td>
    </tr>
    <tr>
      <th>Freezing Rain,Ice Pellets,Fog</th>
      <td>12/17/2012</td>
      <td>03:00:00</td>
      <td>-2.6</td>
      <td>-3.7</td>
      <td>92</td>
      <td>28</td>
      <td>8.0</td>
      <td>100.95</td>
    </tr>
    <tr>
      <th>Freezing Rain,Snow Grains</th>
      <td>1/13/2012</td>
      <td>09:00:00</td>
      <td>-5.0</td>
      <td>-7.3</td>
      <td>84</td>
      <td>32</td>
      <td>4.8</td>
      <td>98.56</td>
    </tr>
    <tr>
      <th>Haze</th>
      <td>02-01-2012</td>
      <td>07:00:00</td>
      <td>-11.5</td>
      <td>-16.0</td>
      <td>68</td>
      <td>0</td>
      <td>4.8</td>
      <td>100.35</td>
    </tr>
    <tr>
      <th>Mainly Clear</th>
      <td>01-02-2012</td>
      <td>00:00:00</td>
      <td>-22.8</td>
      <td>-28.0</td>
      <td>20</td>
      <td>0</td>
      <td>12.9</td>
      <td>98.67</td>
    </tr>
    <tr>
      <th>Moderate Rain,Fog</th>
      <td>12-10-2012</td>
      <td>08:00:00</td>
      <td>1.7</td>
      <td>0.8</td>
      <td>94</td>
      <td>17</td>
      <td>6.4</td>
      <td>99.98</td>
    </tr>
    <tr>
      <th>Moderate Snow</th>
      <td>01-12-2012</td>
      <td>08:00:00</td>
      <td>-6.3</td>
      <td>-7.6</td>
      <td>83</td>
      <td>26</td>
      <td>0.6</td>
      <td>99.88</td>
    </tr>
    <tr>
      <th>Moderate Snow,Blowing Snow</th>
      <td>12/27/2012</td>
      <td>10:00:00</td>
      <td>-5.5</td>
      <td>-6.6</td>
      <td>92</td>
      <td>39</td>
      <td>0.6</td>
      <td>100.50</td>
    </tr>
    <tr>
      <th>Mostly Cloudy</th>
      <td>01-01-2012</td>
      <td>00:00:00</td>
      <td>-23.2</td>
      <td>-28.5</td>
      <td>18</td>
      <td>0</td>
      <td>11.3</td>
      <td>98.36</td>
    </tr>
    <tr>
      <th>Rain</th>
      <td>01-01-2012</td>
      <td>00:00:00</td>
      <td>0.3</td>
      <td>-5.7</td>
      <td>40</td>
      <td>0</td>
      <td>4.0</td>
      <td>97.52</td>
    </tr>
    <tr>
      <th>Rain Showers</th>
      <td>01-01-2012</td>
      <td>00:00:00</td>
      <td>1.6</td>
      <td>-7.2</td>
      <td>37</td>
      <td>0</td>
      <td>6.4</td>
      <td>98.51</td>
    </tr>
    <tr>
      <th>Rain Showers,Fog</th>
      <td>10/20/2012</td>
      <td>03:00:00</td>
      <td>12.8</td>
      <td>12.1</td>
      <td>96</td>
      <td>13</td>
      <td>6.4</td>
      <td>99.83</td>
    </tr>
    <tr>
      <th>Rain Showers,Snow Showers</th>
      <td>11-04-2012</td>
      <td>08:00:00</td>
      <td>2.1</td>
      <td>-1.8</td>
      <td>75</td>
      <td>17</td>
      <td>19.3</td>
      <td>101.09</td>
    </tr>
    <tr>
      <th>Rain,Fog</th>
      <td>03-08-2012</td>
      <td>00:00:00</td>
      <td>0.0</td>
      <td>-1.2</td>
      <td>83</td>
      <td>0</td>
      <td>2.0</td>
      <td>98.61</td>
    </tr>
    <tr>
      <th>Rain,Haze</th>
      <td>3/13/2012</td>
      <td>07:00:00</td>
      <td>4.0</td>
      <td>1.0</td>
      <td>81</td>
      <td>7</td>
      <td>4.0</td>
      <td>100.50</td>
    </tr>
    <tr>
      <th>Rain,Ice Pellets</th>
      <td>12/18/2012</td>
      <td>05:00:00</td>
      <td>0.6</td>
      <td>-0.6</td>
      <td>92</td>
      <td>24</td>
      <td>9.7</td>
      <td>100.12</td>
    </tr>
    <tr>
      <th>Rain,Snow</th>
      <td>01-10-2012</td>
      <td>01:00:00</td>
      <td>0.6</td>
      <td>-1.7</td>
      <td>81</td>
      <td>13</td>
      <td>2.4</td>
      <td>98.18</td>
    </tr>
    <tr>
      <th>Rain,Snow Grains</th>
      <td>12/21/2012</td>
      <td>00:00:00</td>
      <td>1.9</td>
      <td>-2.1</td>
      <td>75</td>
      <td>26</td>
      <td>25.0</td>
      <td>100.60</td>
    </tr>
    <tr>
      <th>Rain,Snow,Fog</th>
      <td>12-08-2012</td>
      <td>21:00:00</td>
      <td>0.8</td>
      <td>0.3</td>
      <td>96</td>
      <td>9</td>
      <td>6.4</td>
      <td>100.73</td>
    </tr>
    <tr>
      <th>Rain,Snow,Ice Pellets</th>
      <td>12/21/2012</td>
      <td>01:00:00</td>
      <td>0.9</td>
      <td>-0.7</td>
      <td>88</td>
      <td>17</td>
      <td>4.8</td>
      <td>99.85</td>
    </tr>
    <tr>
      <th>Snow</th>
      <td>01-03-2012</td>
      <td>00:00:00</td>
      <td>-16.7</td>
      <td>-24.6</td>
      <td>41</td>
      <td>0</td>
      <td>1.0</td>
      <td>97.75</td>
    </tr>
    <tr>
      <th>Snow Pellets</th>
      <td>11/24/2012</td>
      <td>15:00:00</td>
      <td>0.7</td>
      <td>-6.4</td>
      <td>59</td>
      <td>35</td>
      <td>2.4</td>
      <td>99.70</td>
    </tr>
    <tr>
      <th>Snow Showers</th>
      <td>01-02-2012</td>
      <td>00:00:00</td>
      <td>-13.3</td>
      <td>-19.3</td>
      <td>52</td>
      <td>0</td>
      <td>2.4</td>
      <td>99.49</td>
    </tr>
    <tr>
      <th>Snow Showers,Fog</th>
      <td>12/26/2012</td>
      <td>09:00:00</td>
      <td>-11.3</td>
      <td>-12.7</td>
      <td>89</td>
      <td>7</td>
      <td>4.0</td>
      <td>100.63</td>
    </tr>
    <tr>
      <th>Snow,Blowing Snow</th>
      <td>1/13/2012</td>
      <td>00:00:00</td>
      <td>-12.0</td>
      <td>-16.2</td>
      <td>70</td>
      <td>24</td>
      <td>0.6</td>
      <td>98.11</td>
    </tr>
    <tr>
      <th>Snow,Fog</th>
      <td>02-10-2012</td>
      <td>00:00:00</td>
      <td>-10.1</td>
      <td>-12.0</td>
      <td>77</td>
      <td>4</td>
      <td>1.2</td>
      <td>99.38</td>
    </tr>
    <tr>
      <th>Snow,Haze</th>
      <td>02-01-2012</td>
      <td>17:00:00</td>
      <td>-4.3</td>
      <td>-7.2</td>
      <td>80</td>
      <td>0</td>
      <td>4.0</td>
      <td>100.61</td>
    </tr>
    <tr>
      <th>Snow,Ice Pellets</th>
      <td>03-03-2012</td>
      <td>03:00:00</td>
      <td>-4.3</td>
      <td>-5.9</td>
      <td>76</td>
      <td>19</td>
      <td>2.8</td>
      <td>99.40</td>
    </tr>
    <tr>
      <th>Thunderstorms</th>
      <td>07-04-2012</td>
      <td>01:00:00</td>
      <td>21.6</td>
      <td>19.4</td>
      <td>67</td>
      <td>0</td>
      <td>24.1</td>
      <td>99.84</td>
    </tr>
    <tr>
      <th>Thunderstorms,Heavy Rain Showers</th>
      <td>5/29/2012</td>
      <td>06:00:00</td>
      <td>10.9</td>
      <td>9.0</td>
      <td>88</td>
      <td>9</td>
      <td>2.4</td>
      <td>100.26</td>
    </tr>
    <tr>
      <th>Thunderstorms,Moderate Rain Showers,Fog</th>
      <td>7/17/2012</td>
      <td>06:00:00</td>
      <td>19.6</td>
      <td>18.5</td>
      <td>93</td>
      <td>15</td>
      <td>3.2</td>
      <td>100.01</td>
    </tr>
    <tr>
      <th>Thunderstorms,Rain</th>
      <td>5/25/2012</td>
      <td>17:00:00</td>
      <td>19.4</td>
      <td>18.2</td>
      <td>83</td>
      <td>4</td>
      <td>16.1</td>
      <td>100.19</td>
    </tr>
    <tr>
      <th>Thunderstorms,Rain Showers</th>
      <td>07-04-2012</td>
      <td>04:00:00</td>
      <td>11.0</td>
      <td>7.0</td>
      <td>68</td>
      <td>7</td>
      <td>6.4</td>
      <td>99.65</td>
    </tr>
    <tr>
      <th>Thunderstorms,Rain Showers,Fog</th>
      <td>6/29/2012</td>
      <td>03:00:00</td>
      <td>19.5</td>
      <td>16.1</td>
      <td>80</td>
      <td>7</td>
      <td>9.7</td>
      <td>99.71</td>
    </tr>
    <tr>
      <th>Thunderstorms,Rain,Fog</th>
      <td>7/17/2012</td>
      <td>05:00:00</td>
      <td>20.6</td>
      <td>18.6</td>
      <td>88</td>
      <td>19</td>
      <td>4.8</td>
      <td>100.08</td>
    </tr>
  </tbody>
</table>
</div>



<div style="background-color: #FF4734; padding: 10px;">
    <h2 style="color: white;">Show all records where weather condition is fog</h2>
</div>



```python
df[df['Weather condition' ] == 'Fog']
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Time</th>
      <th>Temp_C</th>
      <th>Dew Point Temp_C</th>
      <th>Rel Hum_%</th>
      <th>Wind Speed_km/h</th>
      <th>Visibility_km</th>
      <th>Press_kPa</th>
      <th>Weather condition</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>01-01-2012</td>
      <td>00:00:00</td>
      <td>-1.8</td>
      <td>-3.9</td>
      <td>86</td>
      <td>4</td>
      <td>8.0</td>
      <td>101.24</td>
      <td>Fog</td>
    </tr>
    <tr>
      <th>1</th>
      <td>01-01-2012</td>
      <td>01:00:00</td>
      <td>-1.8</td>
      <td>-3.7</td>
      <td>87</td>
      <td>4</td>
      <td>8.0</td>
      <td>101.24</td>
      <td>Fog</td>
    </tr>
    <tr>
      <th>4</th>
      <td>01-01-2012</td>
      <td>04:00:00</td>
      <td>-1.5</td>
      <td>-3.3</td>
      <td>88</td>
      <td>7</td>
      <td>4.8</td>
      <td>101.23</td>
      <td>Fog</td>
    </tr>
    <tr>
      <th>5</th>
      <td>01-01-2012</td>
      <td>05:00:00</td>
      <td>-1.4</td>
      <td>-3.3</td>
      <td>87</td>
      <td>9</td>
      <td>6.4</td>
      <td>101.27</td>
      <td>Fog</td>
    </tr>
    <tr>
      <th>6</th>
      <td>01-01-2012</td>
      <td>06:00:00</td>
      <td>-1.5</td>
      <td>-3.1</td>
      <td>89</td>
      <td>7</td>
      <td>6.4</td>
      <td>101.29</td>
      <td>Fog</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>8716</th>
      <td>12/29/2012</td>
      <td>04:00:00</td>
      <td>-16.0</td>
      <td>-17.2</td>
      <td>90</td>
      <td>6</td>
      <td>9.7</td>
      <td>101.25</td>
      <td>Fog</td>
    </tr>
    <tr>
      <th>8717</th>
      <td>12/29/2012</td>
      <td>05:00:00</td>
      <td>-14.8</td>
      <td>-15.9</td>
      <td>91</td>
      <td>4</td>
      <td>6.4</td>
      <td>101.25</td>
      <td>Fog</td>
    </tr>
    <tr>
      <th>8718</th>
      <td>12/29/2012</td>
      <td>06:00:00</td>
      <td>-13.8</td>
      <td>-15.3</td>
      <td>88</td>
      <td>4</td>
      <td>9.7</td>
      <td>101.25</td>
      <td>Fog</td>
    </tr>
    <tr>
      <th>8719</th>
      <td>12/29/2012</td>
      <td>07:00:00</td>
      <td>-14.8</td>
      <td>-16.4</td>
      <td>88</td>
      <td>7</td>
      <td>8.0</td>
      <td>101.22</td>
      <td>Fog</td>
    </tr>
    <tr>
      <th>8722</th>
      <td>12/29/2012</td>
      <td>10:00:00</td>
      <td>-12.0</td>
      <td>-13.3</td>
      <td>90</td>
      <td>7</td>
      <td>6.4</td>
      <td>101.15</td>
      <td>Fog</td>
    </tr>
  </tbody>
</table>
<p>150 rows × 9 columns</p>
</div>




```python
df[df['Weather condition'] == 'Fog'].head(20)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Time</th>
      <th>Temp_C</th>
      <th>Dew Point Temp_C</th>
      <th>Rel Hum_%</th>
      <th>Wind Speed_km/h</th>
      <th>Visibility_km</th>
      <th>Press_kPa</th>
      <th>Weather condition</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>01-01-2012</td>
      <td>00:00:00</td>
      <td>-1.8</td>
      <td>-3.9</td>
      <td>86</td>
      <td>4</td>
      <td>8.0</td>
      <td>101.24</td>
      <td>Fog</td>
    </tr>
    <tr>
      <th>1</th>
      <td>01-01-2012</td>
      <td>01:00:00</td>
      <td>-1.8</td>
      <td>-3.7</td>
      <td>87</td>
      <td>4</td>
      <td>8.0</td>
      <td>101.24</td>
      <td>Fog</td>
    </tr>
    <tr>
      <th>4</th>
      <td>01-01-2012</td>
      <td>04:00:00</td>
      <td>-1.5</td>
      <td>-3.3</td>
      <td>88</td>
      <td>7</td>
      <td>4.8</td>
      <td>101.23</td>
      <td>Fog</td>
    </tr>
    <tr>
      <th>5</th>
      <td>01-01-2012</td>
      <td>05:00:00</td>
      <td>-1.4</td>
      <td>-3.3</td>
      <td>87</td>
      <td>9</td>
      <td>6.4</td>
      <td>101.27</td>
      <td>Fog</td>
    </tr>
    <tr>
      <th>6</th>
      <td>01-01-2012</td>
      <td>06:00:00</td>
      <td>-1.5</td>
      <td>-3.1</td>
      <td>89</td>
      <td>7</td>
      <td>6.4</td>
      <td>101.29</td>
      <td>Fog</td>
    </tr>
    <tr>
      <th>7</th>
      <td>01-01-2012</td>
      <td>07:00:00</td>
      <td>-1.4</td>
      <td>-3.6</td>
      <td>85</td>
      <td>7</td>
      <td>8.0</td>
      <td>101.26</td>
      <td>Fog</td>
    </tr>
    <tr>
      <th>8</th>
      <td>01-01-2012</td>
      <td>08:00:00</td>
      <td>-1.4</td>
      <td>-3.6</td>
      <td>85</td>
      <td>9</td>
      <td>8.0</td>
      <td>101.23</td>
      <td>Fog</td>
    </tr>
    <tr>
      <th>9</th>
      <td>01-01-2012</td>
      <td>09:00:00</td>
      <td>-1.3</td>
      <td>-3.1</td>
      <td>88</td>
      <td>15</td>
      <td>4.0</td>
      <td>101.20</td>
      <td>Fog</td>
    </tr>
    <tr>
      <th>10</th>
      <td>01-01-2012</td>
      <td>10:00:00</td>
      <td>-1.0</td>
      <td>-2.3</td>
      <td>91</td>
      <td>9</td>
      <td>1.2</td>
      <td>101.15</td>
      <td>Fog</td>
    </tr>
    <tr>
      <th>11</th>
      <td>01-01-2012</td>
      <td>11:00:00</td>
      <td>-0.5</td>
      <td>-2.1</td>
      <td>89</td>
      <td>7</td>
      <td>4.0</td>
      <td>100.98</td>
      <td>Fog</td>
    </tr>
    <tr>
      <th>12</th>
      <td>01-01-2012</td>
      <td>12:00:00</td>
      <td>-0.2</td>
      <td>-2.0</td>
      <td>88</td>
      <td>9</td>
      <td>4.8</td>
      <td>100.79</td>
      <td>Fog</td>
    </tr>
    <tr>
      <th>13</th>
      <td>01-01-2012</td>
      <td>13:00:00</td>
      <td>0.2</td>
      <td>-1.7</td>
      <td>87</td>
      <td>13</td>
      <td>4.8</td>
      <td>100.58</td>
      <td>Fog</td>
    </tr>
    <tr>
      <th>14</th>
      <td>01-01-2012</td>
      <td>14:00:00</td>
      <td>0.8</td>
      <td>-1.1</td>
      <td>87</td>
      <td>20</td>
      <td>4.8</td>
      <td>100.31</td>
      <td>Fog</td>
    </tr>
    <tr>
      <th>15</th>
      <td>01-01-2012</td>
      <td>15:00:00</td>
      <td>1.8</td>
      <td>-0.4</td>
      <td>85</td>
      <td>22</td>
      <td>6.4</td>
      <td>100.07</td>
      <td>Fog</td>
    </tr>
    <tr>
      <th>166</th>
      <td>01-07-2012</td>
      <td>22:00:00</td>
      <td>-1.5</td>
      <td>-3.0</td>
      <td>89</td>
      <td>4</td>
      <td>4.0</td>
      <td>100.54</td>
      <td>Fog</td>
    </tr>
    <tr>
      <th>408</th>
      <td>1/18/2012</td>
      <td>00:00:00</td>
      <td>2.1</td>
      <td>0.7</td>
      <td>90</td>
      <td>11</td>
      <td>8.0</td>
      <td>98.31</td>
      <td>Fog</td>
    </tr>
    <tr>
      <th>514</th>
      <td>1/22/2012</td>
      <td>10:00:00</td>
      <td>-14.5</td>
      <td>-17.2</td>
      <td>80</td>
      <td>9</td>
      <td>8.0</td>
      <td>103.02</td>
      <td>Fog</td>
    </tr>
    <tr>
      <th>515</th>
      <td>1/22/2012</td>
      <td>11:00:00</td>
      <td>-13.0</td>
      <td>-15.5</td>
      <td>81</td>
      <td>6</td>
      <td>8.0</td>
      <td>103.04</td>
      <td>Fog</td>
    </tr>
    <tr>
      <th>797</th>
      <td>02-03-2012</td>
      <td>05:00:00</td>
      <td>-11.2</td>
      <td>-13.2</td>
      <td>85</td>
      <td>9</td>
      <td>9.7</td>
      <td>102.47</td>
      <td>Fog</td>
    </tr>
    <tr>
      <th>1102</th>
      <td>2/15/2012</td>
      <td>22:00:00</td>
      <td>1.2</td>
      <td>0.0</td>
      <td>92</td>
      <td>7</td>
      <td>6.4</td>
      <td>101.98</td>
      <td>Fog</td>
    </tr>
  </tbody>
</table>
</div>




```python

```


```python
df[(df['Weather condition'] == 'Clear') & (df['Humidity'] > 50) | (df['Visibility_km'] >40)].head(20)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Time</th>
      <th>Temp_C</th>
      <th>Dew Point Temp_C</th>
      <th>Humidity</th>
      <th>Wind Speed_km/h</th>
      <th>Visibility_km</th>
      <th>Press_kPa</th>
      <th>Weather condition</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>106</th>
      <td>01-05-2012</td>
      <td>10:00:00</td>
      <td>-6.0</td>
      <td>-10.0</td>
      <td>73</td>
      <td>17</td>
      <td>48.3</td>
      <td>100.45</td>
      <td>Mainly Clear</td>
    </tr>
    <tr>
      <th>107</th>
      <td>01-05-2012</td>
      <td>11:00:00</td>
      <td>-5.6</td>
      <td>-10.2</td>
      <td>70</td>
      <td>22</td>
      <td>48.3</td>
      <td>100.41</td>
      <td>Mainly Clear</td>
    </tr>
    <tr>
      <th>108</th>
      <td>01-05-2012</td>
      <td>12:00:00</td>
      <td>-4.7</td>
      <td>-9.6</td>
      <td>69</td>
      <td>20</td>
      <td>48.3</td>
      <td>100.38</td>
      <td>Mainly Clear</td>
    </tr>
    <tr>
      <th>109</th>
      <td>01-05-2012</td>
      <td>13:00:00</td>
      <td>-4.4</td>
      <td>-9.7</td>
      <td>66</td>
      <td>26</td>
      <td>48.3</td>
      <td>100.40</td>
      <td>Mainly Clear</td>
    </tr>
    <tr>
      <th>110</th>
      <td>01-05-2012</td>
      <td>14:00:00</td>
      <td>-5.1</td>
      <td>-10.7</td>
      <td>65</td>
      <td>22</td>
      <td>48.3</td>
      <td>100.46</td>
      <td>Mainly Clear</td>
    </tr>
    <tr>
      <th>111</th>
      <td>01-05-2012</td>
      <td>15:00:00</td>
      <td>-4.3</td>
      <td>-12.0</td>
      <td>55</td>
      <td>26</td>
      <td>48.3</td>
      <td>100.52</td>
      <td>Mainly Clear</td>
    </tr>
    <tr>
      <th>114</th>
      <td>01-05-2012</td>
      <td>18:00:00</td>
      <td>-7.1</td>
      <td>-14.4</td>
      <td>56</td>
      <td>11</td>
      <td>25.0</td>
      <td>100.71</td>
      <td>Clear</td>
    </tr>
    <tr>
      <th>115</th>
      <td>01-05-2012</td>
      <td>19:00:00</td>
      <td>-9.2</td>
      <td>-15.4</td>
      <td>61</td>
      <td>7</td>
      <td>25.0</td>
      <td>100.80</td>
      <td>Clear</td>
    </tr>
    <tr>
      <th>116</th>
      <td>01-05-2012</td>
      <td>20:00:00</td>
      <td>-9.8</td>
      <td>-15.7</td>
      <td>62</td>
      <td>9</td>
      <td>25.0</td>
      <td>100.83</td>
      <td>Clear</td>
    </tr>
    <tr>
      <th>117</th>
      <td>01-05-2012</td>
      <td>21:00:00</td>
      <td>-9.0</td>
      <td>-14.8</td>
      <td>63</td>
      <td>13</td>
      <td>25.0</td>
      <td>100.83</td>
      <td>Clear</td>
    </tr>
    <tr>
      <th>183</th>
      <td>01-08-2012</td>
      <td>15:00:00</td>
      <td>-6.6</td>
      <td>-12.9</td>
      <td>61</td>
      <td>20</td>
      <td>48.3</td>
      <td>102.04</td>
      <td>Mostly Cloudy</td>
    </tr>
    <tr>
      <th>241</th>
      <td>01-11-2012</td>
      <td>01:00:00</td>
      <td>-10.7</td>
      <td>-17.8</td>
      <td>56</td>
      <td>17</td>
      <td>25.0</td>
      <td>101.49</td>
      <td>Clear</td>
    </tr>
    <tr>
      <th>242</th>
      <td>01-11-2012</td>
      <td>02:00:00</td>
      <td>-12.0</td>
      <td>-18.9</td>
      <td>56</td>
      <td>19</td>
      <td>25.0</td>
      <td>101.57</td>
      <td>Clear</td>
    </tr>
    <tr>
      <th>243</th>
      <td>01-11-2012</td>
      <td>03:00:00</td>
      <td>-12.7</td>
      <td>-19.4</td>
      <td>57</td>
      <td>19</td>
      <td>25.0</td>
      <td>101.64</td>
      <td>Clear</td>
    </tr>
    <tr>
      <th>244</th>
      <td>01-11-2012</td>
      <td>04:00:00</td>
      <td>-13.4</td>
      <td>-20.1</td>
      <td>57</td>
      <td>17</td>
      <td>25.0</td>
      <td>101.66</td>
      <td>Clear</td>
    </tr>
    <tr>
      <th>324</th>
      <td>1/14/2012</td>
      <td>12:00:00</td>
      <td>-17.5</td>
      <td>-23.8</td>
      <td>58</td>
      <td>20</td>
      <td>48.3</td>
      <td>101.16</td>
      <td>Mostly Cloudy</td>
    </tr>
    <tr>
      <th>325</th>
      <td>1/14/2012</td>
      <td>13:00:00</td>
      <td>-17.1</td>
      <td>-24.1</td>
      <td>55</td>
      <td>17</td>
      <td>48.3</td>
      <td>101.18</td>
      <td>Mainly Clear</td>
    </tr>
    <tr>
      <th>326</th>
      <td>1/14/2012</td>
      <td>14:00:00</td>
      <td>-16.7</td>
      <td>-23.4</td>
      <td>56</td>
      <td>17</td>
      <td>48.3</td>
      <td>101.20</td>
      <td>Mostly Cloudy</td>
    </tr>
    <tr>
      <th>327</th>
      <td>1/14/2012</td>
      <td>15:00:00</td>
      <td>-16.7</td>
      <td>-23.4</td>
      <td>56</td>
      <td>22</td>
      <td>48.3</td>
      <td>101.24</td>
      <td>Mostly Cloudy</td>
    </tr>
    <tr>
      <th>344</th>
      <td>1/15/2012</td>
      <td>08:00:00</td>
      <td>-23.3</td>
      <td>-28.5</td>
      <td>62</td>
      <td>7</td>
      <td>24.1</td>
      <td>102.45</td>
      <td>Clear</td>
    </tr>
  </tbody>
</table>
</div>






```python

```


```python
plt.figure(figsize=(8, 6))
plt.hist(df['Humidity'], bins=20, color='red', alpha=0.7)
plt.xlabel('Humidity')
plt.ylabel('Frequency')
plt.title('Humidity Distribution')
plt.tight_layout()
plt.show()
```


    
![png](output_44_0.png)
    



```python
plt.figure(figsize=(8, 6))
sns.boxplot(x=df['Wind Speed_km/h'], color='green')
plt.xlabel('Wind Speed (km/h)')
plt.title('Wind Speed Distribution')
plt.tight_layout()
plt.show()
```


    
![png](output_45_0.png)
    



```python
plt.figure(figsize=(8, 6))
sns.scatterplot(x='Temp_C', y='Dew Point Temp_C', data=df, color='purple')
plt.xlabel('Temperature (°C)')
plt.ylabel('Dew Point Temperature (°C)')
plt.title('Temperature vs. Dew Point Temperature')
plt.tight_layout()
plt.show()
```


    
![png](output_46_0.png)
    



```python
plt.figure(figsize=(10, 6))
sns.countplot(x='Weather condition', data=df, palette='viridis')
plt.xlabel('Weather Condition')
plt.ylabel('Count')
plt.title('Weather Condition Counts')
plt.xticks(rotation=90)
plt.tight_layout()
plt.show()
```


    
![png](output_47_0.png)
    



```python

```
